<?php
include '../header/header.php';
require_once('../require/connection.php');
if (isset($_REQUEST['id'])) {
    $blog_id=$_REQUEST['id'];
    $query = "SELECT * FROM blog WHERE blog_id=$blog_id";
    $result = mysqli_query($connection,$query);
    $row = mysqli_fetch_assoc($result);
}
?>

<body>
    <?php
    include 'navbar.php';
    ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-md-12 col-sm-12">
                <?php include 'sidebar.php'; ?>
            </div>

            <div class="col-lg-9 col-md-12 col-sm-12" style="margin-top: 60px;">
                <div class="col-12 my-5">
                    <h3 class="text-center text-white fw-bold p-3 rounded shadow" style="background-color: #FFD700;border:3px solid #001F3F;">Edit Blog</h3>
                    <form class="row g-3 my-3" enctype="multipart/form-data" action="edit_blog_process.php" method="POST">
                        <div class="col-md-6">
                            <label for="validationDefault01" class="form-label">Blog Title</label>
                            <input type="text" value="<?php echo $row['blog_title']; ?>" class="form-control" id="validationDefault01" name="title" required>
                        </div>
                        <div class="col-md-6">
                            <label for="validationDefault02" class="form-label">Post Per Page</label>
                            <input type="text" value="<?php echo $row['post_per_page']; ?>" class="form-control" id="validationDefault02" name="post_per_page" required>
                        </div>

                        <div class="col-md-6">
                            <label for="validationDefault03" class="form-label">Blog Image</label>
                            <input type="file"  name="image" class="form-control" accept="image/*" id="validationDefault03">
                        </div>
                        <div class="col-md-6" align="center">
                          <label for="exampleFormControlInput1" class="form-label">Background Image</label>
                            <br>
                            <img class="img-fluid rounded rounded-lg" style="width: 180px;height: 100px;"  src="../<?php echo $row['blog_background_image']; ?>" alt="">
                        </div>
                        <input type="hidden" name="blog_id" value="<?php echo $blog_id;?>">
                        <div class="mb-5 ml-5">
                            <center>
                                <a href="admin.php"><button type="button" class="btn" data-bs-dismiss="modal" style="background-color: #FFD700;">Cancel</button></a>
                                <input type="submit" name="submit" class="btn" value="Update" style="background-color:#001F3F;color: white;">
                            </center>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php
    include '../footer/footer.php';
    ?>
</body>
</html>

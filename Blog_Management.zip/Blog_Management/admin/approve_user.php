<?php
require_once('../require/connection.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';
require '../PHPMailer/src/Exception.php';

if (isset($_REQUEST['id'])) {
	$user_id = $_REQUEST['id'];
	$query = "UPDATE user SET is_approved = 'Approved',is_active ='Active' WHERE user_id = $user_id";
	$result = mysqli_query($connection,$query);
	if ($result) {
		$query = "SELECT * FROM user WHERE user_id=$user_id";
		$result = mysqli_query($connection,$query);
		$row = mysqli_fetch_assoc($result);
		$mail = new PHPMailer();
		$mail->isSMTP();
		$mail->Host = 'smtp.gmail.com';
		$mail->Port = 587;
		$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
		$mail->SMTPAuth = true;
		$mail->Username = 'hostafzal00@gmail.com';
		$mail->Password = 'ndja lvck byxx jszq';
		$mail->setFrom('hostafzal00@gmail.com', 'Online Blogging Application');
		$mail->addReplyTo('hostafzal00@gmail.com', 'Online Blogging Application');
		$mail->addAddress($row['email']);
		$mail->Subject = "Account Activation";
		$mail->isHTML(true);
		$mail->Body  = "Your Account Is Approved By Admin You Can Login Now Your Email is<b>".$row['email']."</b>And Password is <b>".$row['password']."</b>";
		if($mail->send()){
			header("location:pending_user.php?message=Approved Success&alert=alert-success");
		}
		else{
			header("location:pending_user.php?message=Approved Failed&alert=alert-danger");
		}

	}
	else{
		header("location:pending_user.php?message=Approved Failed&alert=alert-danger");
	}
}

?>
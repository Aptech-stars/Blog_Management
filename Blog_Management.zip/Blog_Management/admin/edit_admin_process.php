<?php
require_once('../require/connection.php');
if (isset($_POST['submit'])) {
    extract($_POST);
    if ($_FILES['image']['error']==4) {
    	$query = "UPDATE user SET first_name='".$first_name."',last_name='".$last_name."',email='".$email."',gender='".$gender."',date_of_birth='".$date_of_birth."',address='".$address."',password='".$password."' WHERE user_id=$user_id";
    	   $result =mysqli_query($connection,$query);
    	   if ($result) {
    	       header("location:admin.php?message=Profile Updated Successfully&alert=alert-success");
    	   }
    	   else{
    	       header("location:admin.php?message=Profile Update Failed&alert=alert-danger");
    	   }
    }
    else{
        $tmp_name   = $_FILES['image']['tmp_name'];
        $file_name  = $_FILES['image']['name'];
        $path       = rand()."_".$file_name;
        $path_database  = "Images/".$path; 
        $folder = "../Images";
        if(!is_dir($folder)){
            if(!mkdir($folder)){
            header("location:admin.php?message=Folder Not Created&alert=alert-danger");     
            }
        }

        if(move_uploaded_file($tmp_name, $folder."/".$path)){
            $query = "UPDATE user SET first_name='".$first_name."',last_name='".$last_name."',email='".$email."',gender='".$gender."',date_of_birth='".$date_of_birth."',address='".$address."',user_image='".$path_database."',password='".$password."' WHERE user_id=$user_id";
           $result =mysqli_query($connection,$query);
           if ($result) {
               header("location:admin.php?message=Profile Updated Successfully&alert=alert-success");
           }
           else{
               header("location:admin.php?message=Profile Update Failed&alert=alert-danger");
           }
        }
    }
}
?>
<?php
include '../header/header.php';
require_once('../require/connection.php');
?>
<body>
<?php
include 'navbar.php';
?>
<div class="container-fluid">
<div class="row">
<div class="col-lg-3 col-md-12 col-sm-12">
<?php 
include 'sidebar.php';
$query = "SELECT * FROM blog WHERE user_id ='".$admin['user_id']."' ORDER BY blog_id DESC";
$result = mysqli_query($connection,$query);
?>
</div>
<div class="col-lg-9 col-md-12 col-sm-12" style="margin-top: 60px;">
  <div class="col-12 my-5">
  <h3 class="text-center fw-bold p-3 rounded shadow" style="background-color: #FFD700;border:3px solid #001F3F;">My Blogs</h3>
<div class="table table-responsive">
<table  id="table_id" class="display" style="width:100%" data-ordering="false">
        <thead>
            <tr>
                <th>Blog Title</th>
                <th>Post Per Page</th>
                <th>Image</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($row = mysqli_fetch_assoc($result)) {
            ?>
            <tr>
                <td><?php echo $row['blog_title']; ?></td>
                <td><?php echo $row['post_per_page']; ?></td>
                <td><img src="../<?php echo $row['blog_background_image']; ?>" style="width: 150px;height: 100px;" class="rounded" alt=""></td>
                <td><?php echo $row['blog_status']; ?></td>
                <td>
                 <?php 
                 if ($row['blog_status']=='Active') {
                    ?>
                    <a href="inactive_blog.php?id=<?php echo $row['blog_id']; ?>"><button class="btn btn-danger" style="width: 100px;">InActive</button></a>
                <?php  
                 }
                 ?>
                 <?php
                  if ($row['blog_status']=='InActive') {
                     ?>
                     <a href="active_blog.php?id=<?php echo $row['blog_id']; ?>"><button class="btn btn-success" style="width: 100px;">Active</button></a>
                 <?php  
                  }
                  ?>
                  <a href="edit_blog.php?id=<?php echo $row['blog_id']; ?>"><button class="btn btn-warning" style="width: 100px;">Edit</button></a>
                </td>
            </tr>
            <?php
            }
            ?>
        </tbody>    
</table>
</div>
</div>
</div>
</div>
</div>
</body>
<?php
include '../footer/footer.php';
?>

<?php
include '../header/header.php';
?>

<body>
    <?php
    include 'navbar.php';
    ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-md-12 col-sm-12">
                <?php include 'sidebar.php'; ?>
            </div>

            <div class="col-lg-9 col-md-12 col-sm-12" style="margin-top: 60px;">
                <div class="col-12 my-5">
                    <h3 class="text-center text-white fw-bold p-3 rounded shadow" style="background-color: #FFD700;border:3px solid #001F3F;">Add New Post</h3>
                    <form class="row g-3 my-3" enctype="multipart/form-data" action="add_post_process.php" method="POST">
                        <div class="col-md-6">
                            <label for="validationDefault01" class="form-label">Post Title</label>
                            <input type="text" class="form-control" id="validationDefault01" name="title" required>
                        </div>
                        <div class="col-md-6">
                            <label for="validationDefault01" class="form-label">Post Summary</label>
                            <input type="text" class="form-control" id="validationDefault01" name="summary" required>
                        </div>
                         <div class="col-md-12">
                            <label for="validationDefault01" class="form-label">Post Description</label>
                            <textarea name="description" id="validationDefault01" class="form-control" required></textarea>
                        </div>
                         <div class="col-md-6">
                            <label for="validationDefault03" class="form-label">featured Image</label>
                            <input type="file" name="image" class="form-control" accept="image/*" id="validationDefault03" required>
                        </div>
                        <div class="col-md-6 mt-5">
                           <input class="form-check-input" type="checkbox" name="comments" value="1" id="flexCheckChecked">
                            <label class="form-check-label" for="flexCheckChecked">
                              Allow Comments
                            </label>
                        </div>
                        <div class="col-md-6">
                            <label for="validationDefault03" class="form-label">Blog</label>
                            <select class="form-select" aria-label="Default select example" required name="blog_id">
                              <option value="">--SELECT BLOG--</option>
                              <?php
                                $query = "SELECT * FROM blog WHERE user_id ='".$admin['user_id']."' ORDER BY blog_id DESC";
                                $result = mysqli_query($connection,$query);
                                while ($blog=mysqli_fetch_assoc($result)) {
                                    ?>
                                    <option value="<?php echo $blog['blog_id'];?>"><?php echo $blog['blog_title'];?></option>
                            <?php
                            }
                            ?>
                              
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="validationDefault03" class="form-label">Category</label>
                            <select class="form-select" aria-label="Default select example" required name="category_id">
                              <option value="">--SELECT CATEGORY--</option>
                              <?php
                                $query = "SELECT * FROM category  WHERE user_id='".$admin['user_id']."' ORDER BY category_id DESC";
                                $result = mysqli_query($connection,$query);
                                while ($category=mysqli_fetch_assoc($result)) {
                                    ?>
                                    <option value="<?php echo $category['category_id']; ?>"><?php echo $category['category_title'];?></option>
                            <?php
                            }
                            ?>
                            </select>
                        </div>
                        <div class="col-md-12">
                            <label for="validationDefault03" class="form-label">Attachments</label>
                            <input type="file" name="files[]" class="form-control" id="validationDefault03" multiple>
                        </div>

                        <div class="mb-5 ml-5">
                            <center>
                                <a href="admin.php"><button type="button" class="btn" data-bs-dismiss="modal" style="background-color: #FFD700;">Cancel</button></a>
                                <input type="submit" name="submit" class="btn" value="Create" style="background-color:#001F3F;color: white;">
                            </center>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php
    include '../footer/footer.php';
    ?>
</body>
</html>

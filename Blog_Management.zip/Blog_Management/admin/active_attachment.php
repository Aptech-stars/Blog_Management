<?php
require_once('../require/connection.php');

if (isset($_REQUEST['id'])) {
    $post_attachment_id = $_REQUEST['id'];
    $post_id=$_REQUEST['post_id'];
    $query = "UPDATE post_atachment SET is_active ='Active' WHERE post_atachment_id = $post_attachment_id";
    $result = mysqli_query($connection,$query);
    if ($result) {
        header("location:view_attachment.php?message=Attachment Activated Successfully&alert=alert-success&id=$post_id");
    }
    else{
        header("location:view_attachment.php?message=Activated Failed&alert=alert-danger&id=$post_id");
    }
}

?>
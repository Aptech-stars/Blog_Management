<div class="card" style="margin-top: 100px;">

  <div class="flex-shrink-0 p-3 bg-white">
     <h5 class="card-title p-3 fw-bold rounded shadow" style="background-color:  #FFD700;text-align: center;border:2px solid #001F3F;">Administrator</h5>
      <ul class="list-unstyled ps-0 my-3">
        <li class="mb-1">
          <button class="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#home-collapse" aria-expanded="false">
            Manage Users
          </button>
          <div class="collapse" id="home-collapse">
            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
              <li><a href="add_user.php" class="link-dark rounded">Add New User</a></li>
              <li><a href="view_user.php" class="link-dark rounded">View All Users</a></li>
              <li><a href="active_user.php" class="link-dark rounded">Active Users</a></li>
              <li><a href="inactive_user.php" class="link-dark rounded">InActive Users</a></li>
              <li><a href="pending_user.php" class="link-dark rounded">Pending Users</a></li>
              <li><a href="rejected_user.php" class="link-dark rounded">Rejected Users</a></li>
            </ul>
          </div>
        </li>
        <li class="border-top my-3"></li>
        <li class="mb-1">
          <button class="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#orders-collapse0" aria-expanded="false">
            Manage Admins
          </button>
          <div class="collapse" id="orders-collapse0">
            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
              <li><a href="make_admin.php" class="link-dark rounded">Make Admin</a></li>
              <li><a href="view_admin.php" class="link-dark rounded">View Admins</a></li>
            </ul>
          </div>
        </li>
        <li class="border-top my-3"></li>
        <li class="mb-1">
          <button class="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#dashboard-collapse" aria-expanded="false">
            Manage Blogs
          </button>
          <div class="collapse" id="dashboard-collapse">
            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
              <li><a href="add_blog.php" class="link-dark rounded">Add New Blog</a></li>
              <li><a href="view_blog.php" class="link-dark rounded">View My Blogs</a></li>
            </ul>
          </div>
        </li>
        <li class="border-top my-3"></li>
        <li class="mb-1">
          <button class="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#orders-collapse" aria-expanded="false">
            Manage Categories
          </button>
          <div class="collapse" id="orders-collapse">
            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
              <li><a href="add_category.php" class="link-dark rounded">Add New Category</a></li>
              <li><a href="view_category.php" class="link-dark rounded">View My Categories</a></li>
            </ul>
          </div>
        </li>
        <li class="border-top my-3"></li>
        <li class="mb-1">
          <button class="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#account-collapse" aria-expanded="false">
            Manage Posts
          </button>
          <div class="collapse" id="account-collapse">
            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
              <li><a href="add_post.php" class="link-dark rounded">Add New Post</a></li>
              <li><a href="view_post.php" class="link-dark rounded">View All Posts</a></li>
            </ul>
          </div>
        </li>
        <li class="border-top my-3"></li>
        <li class="mb-1">
          <button class="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#orders-collapse1" aria-expanded="false">
            Manage Comments
          </button>
          <div class="collapse" id="orders-collapse1">
            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
              <li><a href="all_comment.php" class="link-dark rounded">All Comments</a></li>
            </ul>
          </div>
        </li>
        <li class="border-top my-3"></li>
        <li class="mb-1">
          <button class="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#orders-collapse2" aria-expanded="false">
            Manage Feedbacks
          </button>
          <div class="collapse" id="orders-collapse2">
            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
              <li><a href="view_registered_users_feedbacks.php" class="link-dark rounded">Registered Users Feedback</a></li>
              <li><a href="unregistered_feedback.php" class="link-dark rounded">Unregistered Users Feedback</a></li>
            </ul>
          </div>
        </li>
        <li class="border-top my-3"></li>
        <li class="mb-1">
          <button class="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#orders-collapse3" aria-expanded="false">
            Manage Followers
          </button>
          <div class="collapse" id="orders-collapse3">
            <ul class="btn-toggle-nav list-unstyled fw-normal pb-1 small">
              <li><a href="view_followers.php" class="link-dark rounded">View Followers</a></li>
            </ul>
          </div>
        </li>
      </ul>
    </div>
</div>
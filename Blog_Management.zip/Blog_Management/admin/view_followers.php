<?php
include '../header/header.php';
require_once('../require/connection.php');
?>
<body>
<?php
include 'navbar.php';
?>
<div class="container-fluid">
<div class="row">
<div class="col-lg-3 col-md-12 col-sm-12">
<?php 
include 'sidebar.php';
?>
</div>
<div class="col-lg-9 col-md-12 col-sm-12" style="margin-top: 60px;">
  <div class="col-12 my-5">
  <h3 class="text-center fw-bold p-3 rounded shadow" style="background-color: #FFD700;border:3px solid #001F3F;">My Followers</h3>
<div class="table table-responsive">
<table  id="table_id" class="display" style="width:100%" data-ordering="false">
        <thead>
            <tr>
                <th>Follower Name</th>
                <th>Blog Name</th>
                <th>Status</th>     
                <th>Followed On</th>                

            </tr>
        </thead>
        <tbody>
          <?php
          $query = "SELECT B.blog_title,U.first_name,U.last_name,FB.* FROM following_blog FB INNER JOIN user U ON FB.follower_id=U.user_id INNER JOIN blog B ON FB.blog_following_id=B.blog_id WHERE B.user_id='".$admin['user_id']."' ";
          $result = mysqli_query($connection,$query);
          if ($result->num_rows>0) {
           while ($row=mysqli_fetch_assoc($result)) {
             ?>
             <tr>
               <td>
                <?php echo $row['first_name'].' '.$row['last_name']; ?>
               </td>
               <td>
                <?php echo $row['blog_title']; ?>
               </td>
               <td>
                <?php echo $row['status']; ?>
               </td>
                <td>
                <?php echo date('d-M-Y',strtotime($row['created_at'])); ?>
               </td>
             </tr>
             <?php
           }
          }
          ?>
        </tbody>    
</table>
</div>
</div>
</div>
</div>
</div>
</body>
<?php
include '../footer/footer.php';
?>

<?php
require_once('../require/connection.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';
require '../PHPMailer/src/Exception.php';

if (isset($_POST['submit'])) {
    extract($_POST);
    if ($_FILES['image']['error']==4) {
    	$query = "UPDATE user SET first_name='".$first_name."',last_name='".$last_name."',email='".$email."',password='".$password."',gender='".$gender."',date_of_birth='".$date_of_birth."',address='".$address."' WHERE user_id=$user_id";
    	   $result =mysqli_query($connection,$query);
    	   if ($result) {
            $mail = new PHPMailer();
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->Port = 587;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->SMTPAuth = true;
            $mail->Username = 'hostafzal00@gmail.com';
            $mail->Password = 'ndja lvck byxx jszq';
            $mail->setFrom('hostafzal00@gmail.com', 'Online Blogging Application');
            $mail->addReplyTo('hostafzal00@gmail.com', 'Online Blogging Application');
            $mail->addAddress($email);
            $mail->Subject = "Account Update";
            $mail->isHTML(true);
            $mail->Body  = "Your Account Is Updated By Admin Your email is $email And password is $password";
             if($mail->send()){
    	         header("location:view_user.php?message=Profile Updated Successfully&alert=alert-success");
    	       }
           }
    	   else{
    	       header("location:view_user.php?message=Profile Update Failed&alert=alert-danger");
    	   }
    }
    else{
        $tmp_name   = $_FILES['image']['tmp_name'];
        $file_name  = $_FILES['image']['name'];
        $path       = rand()."_".$file_name;
        $path_database  = "Images/".$path; 
        $folder = "../Images";
        if(!is_dir($folder)){
            if(!mkdir($folder)){
            header("location:view_user.php?message=Folder Not Created&alert=alert-danger");     
            }
        }

        if(move_uploaded_file($tmp_name, $folder."/".$path)){
            $query = "UPDATE user SET first_name='".$first_name."',last_name='".$last_name."',email='".$email."',gender='".$gender."',date_of_birth='".$date_of_birth."',address='".$address."',user_image='".$path_database."' WHERE user_id=$user_id";
           $result =mysqli_query($connection,$query);
           if ($result) {
               header("location:view_user.php?message=Profile Updated Successfully&alert=alert-success");
           }
           else{
               header("location:view_user?message=Profile Update Failed&alert=alert-danger");
           }
        }
    }
}
?>
<?php
require_once('../require/connection.php');
if (isset($_POST['submit'])) {
    extract($_POST);
    if ($_FILES['image']['error']==4) {
	    $query = "UPDATE blog SET blog_title='".$title."',post_per_page='".$post_per_page."'WHERE blog_id=$blog_id";
	    $result =mysqli_query($connection,$query);
	    if ($result) {
	        header("location:view_blog.php?message=Blog Updated Successfully&alert=alert-success");
	    }
	    else{
	        header("location:view_blog.php?message=Update Failed&alert=alert-danger");
	    }
	}
	 else{
        $tmp_name   = $_FILES['image']['tmp_name'];
        $file_name  = $_FILES['image']['name'];
        $path       = rand()."_".$file_name;
        $path_database  = "Images/".$path; 
        $folder = "../Images";
        if(!is_dir($folder)){
            if(!mkdir($folder)){
            header("location:view_blog.php?message=Folder Not Created&alert=alert-danger");     
            }
        }

        if(move_uploaded_file($tmp_name, $folder."/".$path)){
           $query = "UPDATE blog SET blog_title='".$title."',post_per_page='".$post_per_page."',blog_background_image='".$path_database."' WHERE blog_id=$blog_id";
           $result =mysqli_query($connection,$query);
           if ($result) {
               header("location:view_blog.php?message=Blog Updated Successfully&alert=alert-success");
           }
           else{
               header("location:view_blog.php?message=Blog Update Failed&alert=alert-danger");
           }
        }
    }
}
?>
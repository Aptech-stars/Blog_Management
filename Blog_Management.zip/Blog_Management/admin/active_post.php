<?php
require_once('../require/connection.php');

if (isset($_REQUEST['id'])) {
    $post_id = $_REQUEST['id'];
    $query = "UPDATE post SET post_status ='Active' WHERE post_id = $post_id";
    $result = mysqli_query($connection,$query);
    if ($result) {
        header("location:view_post.php?message=Post Activated Successfully&alert=alert-success");
    }
    else{
        header("location:view_post.php?message=Activated Failed&alert=alert-danger");
    }
}

?>
<?php
include '../header/header.php';
require_once('../require/connection.php');

?>
<body>
<?php
include 'navbar.php';
?>
<div class="container-fluid">
<div class="row">
<div class="col-lg-3 col-md-12 col-sm-12">
<?php 
include 'sidebar.php';
?>
</div>
<?php
$query = "SELECT * FROM user WHERE is_approved='rejected'";
$result = mysqli_query($connection,$query);

?>
<div class="col-lg-9 col-md-12 col-sm-12" style="margin-top: 60px;">
  <div class="col-12 my-5">
  <h3 class="text-center fw-bold p-3 rounded shadow" style="background-color: #FFD700;border:3px solid #001F3F;">Rejected Users</h3>
<div class="table table-responsive">
<table  id="table_id" class="display" style="width:100%">
        <thead>
            <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Gender</th>
                <th>Date Of Birth</th>
                <th>Image</th>
                <th>Address</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
        	<?php
        	while ($row = mysqli_fetch_assoc($result)) {
        	?>
            <tr>
                <td><?php echo $row['first_name']; ?></td>
                <td><?php echo $row['last_name']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><?php echo $row['gender']; ?></td>
                <td><?php echo $row['date_of_birth']; ?></td>
                <td><img src="../<?php echo $row['user_image']; ?>" style="width: 150px;height: 100px;" class="rounded" alt=""></td>
                <td><?php echo $row['address']; ?></td>
                <td style="color: red;font-weight: bold;"><?php echo $row['is_approved']; ?></td>
            </tr>
            <?php
            }
            ?>
        </tbody>    
</table>
</div>
</div>
</div>

</div>
</div>
</body>
<?php
include '../footer/footer.php';
?>

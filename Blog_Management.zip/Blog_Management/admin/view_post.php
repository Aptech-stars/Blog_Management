<?php
include '../header/header.php';
require_once('../require/connection.php');
?>
<body>
<?php
include 'navbar.php';
?>
<div class="container-fluid">
<div class="row">
<div class="col-lg-3 col-md-12 col-sm-12">
<?php 
include 'sidebar.php';
$query = "SELECT * FROM post WHERE user_id='".$admin['user_id']."' ORDER BY post_id DESC";
$result = mysqli_query($connection,$query);
?>
</div>
<div class="col-lg-9 col-md-12 col-sm-12" style="margin-top: 60px;" >
  <div class="col-12 my-5">
  <h3 class="text-center fw-bold p-3 rounded shadow" style="background-color: #FFD700;border:3px solid #001F3F;">All Posts</h3>
<div class="table table-responsive">
<table  id="table_id" class="display" style="width:100%" data-ordering="false">
        <thead>
            <tr>
                <th>Post Title</th>
                <th>Post Summary</th>
                <th>Post Description</th>
                <th>Blog</th>
                <th>Category</th>
                <th>Image</th>
                <th>Status</th>
                <th>Comments</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($row = mysqli_fetch_assoc($result)) {
            ?>
            <tr>
                <td><?php echo $row['post_title']; ?></td>
                <td><?php echo $row['post_summary']; ?></td>
                <td><?php echo $row['post_description']; ?></td>
                <td>
                  <?php
                  $query1="SELECT * FROM blog WHERE blog_id='".$row['blog_id']."'";
                  $result1=mysqli_query($connection,$query1);
                  $blog_name=mysqli_fetch_assoc($result1);
                  echo $blog_name['blog_title'];
                  ?>
                </td>
                <td>
                  <?php
                  $query2="SELECT * FROM category WHERE category_id='".$row['category_id']."'";
                  $result2=mysqli_query($connection,$query2);
                  $category_name=mysqli_fetch_assoc($result2);
                  echo $category_name['category_title'];
                  ?>
                </td>

                <td><img src="../<?php echo $row['featured_image']; ?>" style="width: 150px;height: 100px;" class="rounded" alt=""></td>
                <td><?php echo $row['post_status']; ?></td>
                <td>
                  <?php 
                  if ($row['is_comment_allowed']==1) {
                   echo "Allowed";
                  }
                  else{
                    echo "Not Allowed";
                  }
                  ?>
                </td>
                <td>
                 <?php 
                 if ($row['post_status']=='Active') {
                    ?>
                    <a href="inactive_post.php?id=<?php echo $row['post_id']; ?>"><button class="btn btn-danger" style="width: 100px;">InActive</button></a>
                <?php  
                 }
                 ?>
                 <?php
                  if ($row['post_status']=='InActive') {
                     ?>
                     <a href="active_post.php?id=<?php echo $row['post_id']; ?>"><button class="btn btn-success" style="width: 100px;">Active</button></a>
                 <?php  
                  }
                  ?>
                  <a href="edit_post.php?id=<?php echo $row['post_id']; ?>"><button class="btn btn-warning" style="width: 100px;">Edit</button></a>
                  <a href="view_attachment.php?id=<?php echo $row['post_id']; ?>"><button class="btn btn-secondary" style="width: 100px;">View Attachments</button></a>
                </td>
            </tr>
            <?php
            }
            ?>
        </tbody>    
</table>
</div>
</div>
</div>
</div>
</div>
</body>
<?php
include '../footer/footer.php';
?>

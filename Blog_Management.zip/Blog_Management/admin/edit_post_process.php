<?php
require_once('../require/connection.php');
if (isset($_POST['submit'])) {
    extract($_POST);
    $comment_allowed=0;
    if (isset($comments)) {
        $comment_allowed=1;
    }
    if ($_FILES['image']['error']==4) {
      $query = "UPDATE post SET post_title='".$title."',post_summary='".$summary."',post_description='".$description."' , blog_id='".$blog_id."', category_id='".$category_id."' , is_comment_allowed='".$comment_allowed."' WHERE post_id=$post_id";
      $result =mysqli_query($connection,$query);
      if ($result) {
          if($_FILES['files']['error'][0]!='4'){
              $folder_attach = "../Attachments";
              if(!is_dir($folder_attach)){
                  if(!mkdir($folder_attach)){
                  header("location:admin.php?message=Folder Not Created");    
                  }
              }
              foreach ($_FILES['files']['name'] as $key => $value) {
                      $tmp_name = $_FILES['files']['tmp_name'][$key];
                      $file_name_original = $_FILES['files']['name'][$key];
                      $file_name_upload = rand()."_".$_FILES['files']['name'][$key];
                      $path = $folder_attach."/".$file_name_upload;
                      
                  if(move_uploaded_file($tmp_name, $path)){
                      $query = "INSERT INTO post_atachment VALUES(null,'".$post_id."','".$file_name_original."','".$path."','Active',null,null)";
                      $result = mysqli_query($connection,$query);
                  }
              }
          }
          header("location:view_post.php?message=Post Updated Successfully&alert=alert-success");
      }
      else{
          header("location:view_post.php?message=Update Failed&alert=alert-danger");
      }
    }
   else{
        $tmp_name   = $_FILES['image']['tmp_name'];
        $file_name  = $_FILES['image']['name'];
        $path       = rand()."_".$file_name;
        $path_database  = "Images/".$path; 
        $folder = "../Images";
        if(!is_dir($folder)){
            if(!mkdir($folder)){
            header("location:view_post.php?message=Folder Not Created&alert=alert-danger");     
            }
        }

        if(move_uploaded_file($tmp_name, $folder."/".$path)){
            $query = "UPDATE post SET post_title='".$title."',post_summary='".$summary."',post_description='".$description."' , blog_id='".$blog_id."', category_id='".$category_id."' , is_comment_allowed='".$comment_allowed."',featured_image='".$path_database."' WHERE post_id=$post_id";
           $result =mysqli_query($connection,$query);
           if ($result) {
               if($_FILES['files']['error'][0]!='4'){
                   $folder_attach = "../Attachments";
                   if(!is_dir($folder_attach)){
                       if(!mkdir($folder_attach)){
                       header("location:admin.php?message=Folder Not Created");    
                       }
                   }
                   foreach ($_FILES['files']['name'] as $key => $value) {
                           $tmp_name = $_FILES['files']['tmp_name'][$key];
                           $file_name_original = $_FILES['files']['name'][$key];
                           $file_name_upload = rand()."_".$_FILES['files']['name'][$key];
                           $path = $folder_attach."/".$file_name_upload;
                           
                       if(move_uploaded_file($tmp_name, $path)){
                           $query = "INSERT INTO post_atachment VALUES(null,'".$post_id."','".$file_name_original."','".$path."','Active',null,null)";
                           $result = mysqli_query($connection,$query);
                       }
                   }
               }
               header("location:view_post.php?message=Post Updated Successfully&alert=alert-success");
           }
           else{
               header("location:view_post.php?message=Post Update Failed&alert=alert-danger");
           }
        }
    }
}
?>
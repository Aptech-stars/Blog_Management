<?php
session_start();
require_once("../require/connection.php");

if (isset($_SESSION['role_id'])) {
	if ($_SESSION['role_id']==1) {
		$user_id= $_SESSION['user_id'];
		$query= "SELECT * FROM user WHERE user_id=$user_id";
		$result= mysqli_query($connection,$query);
		$admin= mysqli_fetch_assoc($result);
	}
	else{
		header("location:../index.php?message=You Are Not Admin&alert=alert-danger");
	}
}
else{
	header("location:../index.php?message=Login First&alert=alert-danger");
}
?>
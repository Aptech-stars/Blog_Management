<?php
include '../header/header.php';
include 'navbar.php';
// include 'session.php'; 
require_once("../require/connection.php");

?>
<body>
<div class="container-fluid">
<div class="row">
<div class="col-xl-3 col-lg-3 col-xxl-3 col-sm-12 col-md-12">
<?php include 'sidebar.php'; ?>
</div>



<div class="col-xl-9 col-lg-9 col-xxl-9 col-sm-12 col-md-12">
<div class="card" style="margin-top: 100px;">
  <div class="card-body">
       <h5 class="card-title p-3 fw-bold rounded shadow" style="background-color:  #FFD700;text-align: center;border:2px solid #001F3F;">Admin Panel</h5>
       <div class="row mt-4">

        <?php 
        $query_active_user = "SELECT COUNT(user_id) as user_id FROM user WHERE is_active='Active' AND is_approved='Approved' AND role_id='2'";
        $result_active_user = mysqli_query($connection,$query_active_user);
        $active_user_details=mysqli_fetch_assoc($result_active_user);
        ?>

         <div class="col-lg-4 col-xl-4 col-xxl-4 col-sm-12 col-md-12">
          <div class="card mb-3" style="border:2px solid #001F3F;">
          <div class="card-header p-3 fw-bold rounded shadow text-center">Active Users : <?php echo $active_user_details['user_id']; ?></div>
          <div class="card-body text-warning">
           		<center>
           		  <a href="active_user.php">
           		    <button type="button" class="btn btn-outline-light text-white rounded shadow" style="background-color: #001F3F;">View Active Users
           		    </button>
           		  </a>
           		</center>
          </div>
          </div>
         </div>

         <?php 
         $query_inactive_user = "SELECT COUNT(user_id) as user_id FROM user WHERE is_active='InActive' AND is_approved='Approved' AND role_id='2'";
         $result_inactive_user = mysqli_query($connection,$query_inactive_user);
         $inactive_user_details=mysqli_fetch_assoc($result_inactive_user);
         ?>

         <div class="col-lg-4 col-xl-4 col-xxl-4 col-sm-12 col-md-12">
          <div class="card mb-3" style="border:2px solid #001F3F;">
          <div class="card-header p-3 fw-bold rounded shadow text-center">InActive Users : <?php echo $inactive_user_details['user_id']; ?></div>
          <div class="card-body text-warning">
           		<center>
           		  <a href="inactive_user.php">
           		    <button type="button" class="btn btn-outline-light text-white rounded shadow" style="background-color: #001F3F;">View InActive Users
           		    </button>
           		  </a>
           		</center>
          </div>
          </div>
         </div>

         <?php 
         $query_pending_user = "SELECT COUNT(user_id) as user_id FROM user WHERE is_approved='Pending' AND role_id='2'";
         $result_pending_user = mysqli_query($connection,$query_pending_user);
         $pending_user_details=mysqli_fetch_assoc($result_pending_user);
         ?>

         <div class="col-lg-4 col-xl-4 col-xxl-4 col-sm-12 col-md-12">
          <div class="card mb-3" style="border:2px solid #001F3F;">
          <div class="card-header p-3 fw-bold rounded shadow text-center">Pending Users : <?php echo $pending_user_details['user_id']; ?></div>
          <div class="card-body text-warning">
           		<center>
           		  <a href="pending_user.php">
           		    <button type="button" class="btn btn-outline-light text-white rounded shadow" style="background-color: #001F3F;">View Pending Users
           		    </button>
           		  </a>
           		</center>
          </div>
          </div>
         </div>

       </div> 

       <?php 
       $query_rejected_user = "SELECT COUNT(user_id) as user_id FROM user WHERE is_approved='Rejected' AND role_id='2'";
       $result_rejected_user = mysqli_query($connection,$query_rejected_user);
       $rejected_user_details=mysqli_fetch_assoc($result_rejected_user);
       ?>

        <div class="row">
         <div class="col-lg-4 col-xl-4 col-xxl-4 col-sm-12 col-md-12">
          <div class="card mb-3" style="border:2px solid #001F3F;">
          <div class="card-header p-3 fw-bold rounded shadow text-center">Rejected Users : <?php echo $rejected_user_details['user_id']; ?></div>
          <div class="card-body text-warning p-4 my-4">
           		<center>
           		  <a href="rejected_user.php">
           		    <button type="button" class="btn btn-outline-light text-white rounded shadow " style="background-color: #001F3F;">View Rejected Users
           		    </button>
           		  </a>
           		</center>
          </div>
          </div>
         </div>

         <?php 
         $query_registered_user = "SELECT COUNT(feedback_id) as user_id FROM user_feedback WHERE user_id!='Null'";
         $result_registered_user = mysqli_query($connection,$query_registered_user);
         $registered_user_details=mysqli_fetch_assoc($result_registered_user);
         ?>

         <div class="col-lg-4 col-xl-4 col-xxl-4 col-sm-12 col-md-12">
          <div class="card mb-3" style="border:2px solid #001F3F;">
          <div class="card-header p-3 fw-bold rounded shadow text-center">Registered Users Feedbacks : <?php echo $registered_user_details['user_id']; ?></div>
          <div class="card-body text-warning my-3 p-3 ">
           		<center>
           		  <a href="view_registered_users_feedbacks.php">
           		    <button type="button" class="btn btn-outline-light text-white rounded shadow" style="background-color: #001F3F;">View Registered Users Feedbacks
           		    </button>
           		  </a>
           		</center>
          </div>
          </div>
         </div>

         <?php 
         $query_unregistered_user = "SELECT COUNT(feedback_id) as user_id FROM user_feedback WHERE user_id IS NULL";
         $result_unregistered_user = mysqli_query($connection,$query_unregistered_user);
         $unregistered_user_details=mysqli_fetch_assoc($result_unregistered_user);
         ?>

         <div class="col-lg-4 col-xl-4 col-xxl-4 col-sm-12 col-md-12">
          <div class="card mb-3" style="border:2px solid #001F3F;">
          <div class="card-header p-3 fw-bold rounded shadow text-center">UnRegistered Users Feedbacks : <?php echo $unregistered_user_details['user_id']; ?></div>
          <div class="card-body text-warning my-1">
           		<center>
           		  <a href="unregistered_feedback.php">
           		    <button type="button" class="btn btn-outline-light text-white rounded shadow" style="background-color: #001F3F;">View UnRegistereds Users Feedbacks
           		    </button>
           		  </a>
           		</center>
          </div>
          </div>
         </div>
         
       </div>

       <?php 
       $query_all_comments = "SELECT COUNT(post_comment_id) as user_id FROM post_comment";
       $result_all_comments = mysqli_query($connection,$query_all_comments);
       $all_comments_details=mysqli_fetch_assoc($result_all_comments);
       ?> 


         <div class="row">
          <div class="col-lg-4 col-xl-4 col-xxl-4 col-sm-12 col-md-12">
           <div class="card mb-3" style="border:2px solid #001F3F;">
           <div class="card-header p-3 fw-bold rounded shadow text-center">All Comments : <?php echo $all_comments_details['user_id']; ?></div>
           <div class="card-body text-warning">
           		<center>
           		  <a href="all_comment.php">
           		    <button type="button" class="btn btn-outline-light text-white rounded shadow" style="background-color: #001F3F;">View All Comments
           		    </button>
           		  </a>
           		</center>
          </div>
           </div>
          </div>

          <?php 
          $query_all_posts = "SELECT COUNT(post_id) as user_id FROM post";
          $result_all_posts = mysqli_query($connection,$query_all_posts);
          $all_posts_details=mysqli_fetch_assoc($result_all_posts);
          ?>

          <div class="col-lg-4 col-xl-4 col-xxl-4 col-sm-12 col-md-12">
           <div class="card mb-3" style="border:2px solid #001F3F;">
           <div class="card-header p-3 fw-bold rounded shadow text-center">Total Posts : <?php echo $all_posts_details['user_id']; ?></div>
           <div class="card-body text-warning">
           		<center>
           		  <a href="view_post.php">
           		    <button type="button" class="btn btn-outline-light text-white rounded shadow" style="background-color: #001F3F;">View All Posts
           		    </button>
           		  </a>
           		</center>
          </div>
           </div>
          </div>


          <?php 
          $query_inactive_user = "SELECT COUNT(user_id) as user_id FROM user WHERE is_active='InActive'";
          $result_inactive_user = mysqli_query($connection,$query_inactive_user);
          $inactive_user_details=mysqli_fetch_assoc($result_inactive_user);
          ?>

          <div class="col-lg-4 col-xl-4 col-xxl-4 col-sm-12 col-md-12">
           <div class="card mb-3" style="border:2px solid #001F3F;">
           <div class="card-header p-3 fw-bold rounded shadow text-center">Blog Followers</div>
           <div class="card-body text-warning">
           		<center>
           		  <a href="active_user.php">
           		    <button type="button" class="btn btn-outline-light text-white rounded shadow" style="background-color: #001F3F;">View Blog Followers
           		    </button>
           		  </a>
           		</center>
          </div>
           </div>
          </div>
          
        </div>

         <div class="row">



         <?php 
         $query_my_blogs = "SELECT COUNT(blog_id) as blog_id FROM blog WHERE user_id='".$admin['user_id']."'";
         $result_my_blogs = mysqli_query($connection,$query_my_blogs);
         $my_blogs_details=mysqli_fetch_assoc($result_my_blogs);
         ?>

         <div class="col-lg-4 col-xl-4 col-xxl-4 col-sm-12 col-md-12"style="margin-left: 150px;">
          <div class="card mb-3" style="border:2px solid #001F3F;">
          <div class="card-header p-3 fw-bold rounded shadow text-center">My Blogs : <?php echo $my_blogs_details['blog_id']; ?></div>
          <div class="card-body text-warning">
          		<center>
          		  <a href="view_blog.php">
          		    <button type="button" class="btn btn-outline-light text-white rounded shadow" style="background-color: #001F3F;">View My Blogs
          		    </button>
          		  </a>
          		</center>
         </div>
          </div>
         </div>

          <?php 
          $query_my_categories = "SELECT COUNT(category_id) as category_id FROM category WHERE user_id='".$admin['user_id']."'";
          $result_my_categories = mysqli_query($connection,$query_my_categories);
          $my_categories_details=mysqli_fetch_assoc($result_my_categories);
          ?>

          <div class="col-lg-4 col-xl-4 col-xxl-4 col-sm-12 col-md-12">
           <div class="card mb-3" style="border:2px solid #001F3F;">
           <div class="card-header p-3 fw-bold rounded shadow text-center">My Categories : <?php echo $my_categories_details['category_id']; ?></div>
           <div class="card-body text-warning">
           		<center>
           		  <a href="view_category.php">
           		    <button type="button" class="btn btn-outline-light text-white rounded shadow" style="background-color: #001F3F;">View My Categories
           		    </button>
           		  </a>
           		</center>
          </div>
           </div>
          </div>

      
          
        </div> 
        </div> 
    </div>
</div>
</div>
</div>



<?php
include '../footer/footer.php';
?>
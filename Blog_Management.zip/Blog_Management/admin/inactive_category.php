<?php
require_once('../require/connection.php');

if (isset($_REQUEST['id'])) {
	$category_id = $_REQUEST['id'];
	$query = "UPDATE category SET category_status ='InActive' WHERE category_id = $category_id";
	$result = mysqli_query($connection,$query);
	if ($result) {
		header("location:view_category.php?message=Category InActive Successfully&alert=alert-success");
	}
	else{
		header("location:view_category.php?message=Category InActive Failed&alert=alert-danger");
	}
}

?>
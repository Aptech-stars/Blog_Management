<?php
require_once('../require/connection.php');

if (isset($_REQUEST['id'])) {
	$post_comment_id = $_REQUEST['id'];
	$query = "UPDATE post_comment SET is_active ='Active' WHERE post_comment_id = $post_comment_id";
	$result = mysqli_query($connection,$query);
	if ($result) {
		header("location:all_comment.php?message=Comment Activated Successfully&alert=alert-success");
	}
	else{
		header("location:all_comment.php?message=Activated Failed&alert=alert-danger");
	}
}

?>
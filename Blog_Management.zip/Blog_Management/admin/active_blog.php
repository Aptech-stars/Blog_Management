<?php
require_once('../require/connection.php');

if (isset($_REQUEST['id'])) {
	$blog_id = $_REQUEST['id'];
	$query = "UPDATE blog SET blog_status ='Active' WHERE blog_id = $blog_id";
	$result = mysqli_query($connection,$query);
	if ($result) {
		header("location:view_blog.php?message=Blog Activated Successfully&alert=alert-success");
	}
	else{
		header("location:view_blog.php?message=Activated Failed&alert=alert-danger");
	}
}

?>
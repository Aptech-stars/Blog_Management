<?php
include '../header/header.php';
require_once('../require/connection.php');
?>
<body>
<?php
include 'navbar.php';
?>
<div class="container-fluid">
<div class="row">
<div class="col-lg-3 col-md-12 col-sm-12">
<?php 
include 'sidebar.php';
if (isset($_REQUEST['id'])) {
  $attachment_id=$_REQUEST['id'];
}
$query = "SELECT * FROM post_atachment WHERE post_id='".$attachment_id."' ORDER BY post_atachment_id DESC";
$result = mysqli_query($connection,$query);
?>
</div>
<div class="col-lg-9 col-md-12 col-sm-12" style="margin-top: 60px;" >
  <div class="col-12 my-5">
  <h3 class="text-center fw-bold p-3 rounded shadow" style="background-color: #FFD700;border:3px solid #001F3F;"><a href="view_post.php"><button style="float: left;" class="btn btn-outline-dark">Back</button></a>Attachments</h3>
<div class="table table-responsive">
<table  id="table_id" class="display" style="width:100%" data-ordering="false">
        <thead>
            <tr>
                <th>Attchement Title</th>
                <th>Attchement Title</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows>0) {
            while ($row = mysqli_fetch_assoc($result)) {
            ?>
            <tr>
                <td><?php echo $row['post_attachment_title']; ?></td>
                <td><a href="<?php echo $row['post_attachment_path'];?>" download>View File</a></td>
                <td>
                 <?php 
                 if ($row['is_active']=='Active') {
                    ?>
                    <a href="inactive_attachment.php?id=<?php echo $row['post_atachment_id']; ?>&post_id=<?php echo $attachment_id;?>"><button class="btn btn-danger" style="width: 100px;">InActive</button></a>
                <?php  
                 }
                 ?>
                 <?php
                  if ($row['is_active']=='InActive') {
                     ?>
                     <a href="active_attachment.php?id=<?php echo $row['post_atachment_id']; ?>&post_id=<?php echo $attachment_id;?>"><button class="btn btn-success" style="width: 100px;">Active</button></a>
                 <?php  
                  }
                  ?>
                </td>
            </tr>
            <?php
            }}
            ?>
        </tbody>    
</table>
</div>
</div>
</div>
</div>
</div>
</body>
<?php
include '../footer/footer.php';
?>

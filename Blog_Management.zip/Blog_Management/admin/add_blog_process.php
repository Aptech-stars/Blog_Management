<?php
require_once('../require/connection.php');
include 'session.php';

if (isset($_POST['submit'])) {
    extract($_POST);
     $tmp_name   = $_FILES['image']['tmp_name'];
        $file_name  = $_FILES['image']['name'];
        $path       = rand()."_".$file_name;
        $path_database  = "Images/".$path; 
        $folder = "../Images";
        if(!is_dir($folder)){
            if(!mkdir($folder)){
            header("location:add_blog.php?message=Folder Not Created&alert=alert-danger");     
            }
        }

    if(move_uploaded_file($tmp_name, $folder."/".$path)){
    $query = "INSERT INTO blog VALUES(null,'".$admin['user_id']."','".$title."','".$post_per_page."','".$path_database."','Active',null,null)";
    $result = mysqli_query($connection,$query);
    if($result){
    header("location:add_blog.php?message=Blog Created Success&alert=alert-success");
    }
    else
    {
        $error=mysqli_error($connection)." Some Errors ";
        header("location:add_blog.php?message=$error&alert=alert-danger");
    }}
}
?>

<?php
require_once('../require/connection.php');
include 'session.php';

if (isset($_POST['submit'])) {
    extract($_POST);
    $query = "INSERT INTO category VALUES(null,'".$title."','".$discription."','Active',null,null,'".$admin['user_id']."')";
    $result = mysqli_query($connection,$query);
    if($result){
    header("location:add_category.php?message=Category Added Success&alert=alert-success");
    }
    else
    {
        $error=mysqli_error($connection)." Some Errors ";
        header("location:add_category.php?message=$error&alert=alert-danger");
    } 
}
?>

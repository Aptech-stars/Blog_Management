<?php
require_once('../require/connection.php');

if (isset($_REQUEST['id'])) {
	$blog_id = $_REQUEST['id'];
	$query = "UPDATE blog SET blog_status ='InActive' WHERE blog_id = $blog_id";
	$result = mysqli_query($connection,$query);
	if ($result) {
		header("location:view_blog.php?message=blog InActive Successfully&alert=alert-success");
	}
	else{
		header("location:view_blog.php?message=blog InActive Failed&alert=alert-danger");
	}
}

?>
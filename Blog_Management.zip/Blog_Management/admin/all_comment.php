<?php
include '../header/header.php';
require_once('../require/connection.php');

?>
<body>
<?php
include 'navbar.php';
?>
<div class="container-fluid">
<div class="row">
<div class="col-lg-3 col-md-12 col-sm-12">
<?php 
include 'sidebar.php';
?>
</div>
<?php
$query_comment = "SELECT P.post_title,U.first_name,U.last_name,PC.* FROM post_comment PC INNER JOIN user U ON PC.user_id=U.user_id INNER JOIN post P ON PC.post_id = P.post_id ORDER BY PC.post_comment_id DESC";
$result_comment = mysqli_query($connection,$query_comment);

?>
<div class="col-lg-9 col-md-12 col-sm-12" style="margin-top: 60px;">
  <div class="col-12 my-5">
  <h3 class="text-center fw-bold p-3 rounded shadow" style="background-color: #FFD700;border:3px solid #001F3F;">All Comments</h3>
<div class="table table-responsive">
<table  id="table_id" class="display" style="width:100%" data-ordering="false">
        <thead>
            <tr>
                <th>User Name</th>
                <th>Post Title</th>
                <th>Comment Description</th>
                <th>Commented On</th>
                <th>Status</th>
                <th>Action</th> 
            </tr>
        </thead>
        <tbody>
        	<?php
        	if ($result_comment->num_rows>0) {
               while ($comments = mysqli_fetch_assoc($result_comment)) {
        	?>
            <tr>
                <td><?php echo $comments['first_name'].' '.$comments['last_name'];?></td>
                <td><?php echo $comments['post_title'];?></td>
                <td><?php echo $comments['comment'];?></td>
                <td><?php echo date('d-m-Y',strtotime($comments['created_at']))?></td>
                <td><?php echo $comments['is_active'];?></td>
                <td>
                 <?php 
                 if ($comments['is_active']=='Active') {
                    ?>
                    <a href="inactive_comment.php?id=<?php echo $comments['post_comment_id']; ?>"><button class="btn btn-danger" style="width: 100px;">InActive</button></a>
                <?php  
                 }
                 ?>
                 <?php
                  if ($comments['is_active']=='InActive') {
                     ?>
                     <a href="active_comment.php?id=<?php echo $comments['post_comment_id']; ?>"><button class="btn btn-success" style="width: 100px;">Active</button></a>
                 <?php  
                  }
                  ?>




            </tr>            
            <?php
            }
            }
            ?>
        </tbody>    
</table>
</div>
</div>
</div>

</div>
</div>
</body>
<?php
include '../footer/footer.php';
?>

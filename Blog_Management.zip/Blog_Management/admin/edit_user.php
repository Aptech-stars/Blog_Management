<?php
include '../header/header.php';
require_once('../require/connection.php');
if (isset($_REQUEST['id'])) {
    $user_id=$_REQUEST['id'];
    $query = "SELECT * FROM user WHERE user_id=$user_id";
    $result = mysqli_query($connection,$query);
    $row = mysqli_fetch_assoc($result);
}
?>

<body>
    <?php
    include 'navbar.php';
    ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-md-12 col-sm-12">
                <?php include 'sidebar.php'; ?>
            </div>

            <div class="col-lg-9 col-md-12 col-sm-12" style="margin-top: 60px;">
                <div class="col-12 my-5">
                 
                    <h3 class="text-center text-white fw-bold p-3 rounded shadow" style="background-color: #FFD700;border:3px solid #001F3F;">Edit User</h3>
                       <form class="row g-3" action="edit_user_process.php" method="POST" enctype="multipart/form-data">
                      <div class="col-md-6">
                        <label for="validationDefault01" class="form-label">First name</label>
                        <input type="text" class="form-control" value="<?php echo $row['first_name'];?>" id="first_name" name="first_name" >
                      </div>
                      <div class="col-md-6">
                        <label for="validationDefault02" class="form-label">Last name</label>
                        <input type="text" class="form-control" value="<?php echo $row['last_name'];?>" id="last_name" name="last_name" required>
                      </div>
                      <div class="col-md-6">
                        <label for="validationDefaultUsername" class="form-label">Email</label>
                        <div class="input-group">
                          <span class="input-group-text" id="inputGroupPrepend2">@</span>
                          <input type="email" class="form-control" value="<?php echo $row['email'];?>" id="email" aria-describedby="inputGroupPrepend2"  name="email" required>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <label for="validationDefaultUsername" class="form-label">Password</label>
                        <div class="input-group">
                          <input type="text" class="form-control" value="<?php echo $row['password'];?>" id="password" aria-describedby="inputGroupPrepend2"  name="password" required>
                        </div>
                      </div>
                      <div class="col-md-3">
                          <label for="exampleFormControlInput1" class="form-label">Gender</label>
                            <br>
                            <label for="exampleFormControlInput1" class="form-label">Male</label>
                            <input class="form-check-input" type="radio"  name="gender" id="male" value="male" required 
                            <?php if($row['gender']=='Male'){
                            ?> checked 
                            <?php
                              }
                            ?>
                            >
                          &nbsp;&nbsp;
                          <!-- <div class="form-check"> -->
                            <label class="form-check-label" for="flexRadioDefault1">Female</label>
                            <input class="form-check-input" type="radio" name="gender" id="female" value="female" required
                            <?php if($row['gender']=='Female'){
                            ?> checked 
                            <?php
                              }
                            ?>
                            >
                      </div>
                      <div class="col-md-3">
                          <label for="exampleFormControlInput1" class="form-label">Profile Image</label>
                            <br>
                            <img class="img-fluid" style="width: 100px;height: 100px;"  src="../<?php echo $row['user_image']; ?>" alt="">
                      </div>
                      <div class="col-md-6">
                        <label for="validationDefault03" class="form-label">Date Of Birth</label>
                        <input type="date" class="form-control" value="<?php echo $row['date_of_birth'];?>" id="date_of_birth" name="date_of_birth" required>
                      </div>
                       <div class="col-md-6">
                        <label for="validationDefault03" class="form-label">Profile Image</label>
                        <input type="file" name="image" id="iamge" class="form-control" accept="image/*" id="validationDefault03" >
                      </div>
                      <div class="col-md-12">
                      <label for="exampleFormControlTextarea1" class="form-label">Address</label>
                      <textarea class="form-control" id="address" rows="5" name="address" required><?php echo $row['address'];?></textarea>
                      </div>
                        <input type="hidden" name="user_id" value="<?php echo $row['user_id'];?>">
                    </center>
                      

                      <div class="mb-3 mt-5 ml-5">
                        <center>
                          <a href="my_profile.php"><button type="button" class="btn" data-bs-dismiss="modal" style="background-color: #FFD700;">Cancel</button></a>
                          <input type="submit" name="submit" class="btn" value="Update" style="background-color:#001F3F;color: white;">
                        </center>
                        </div>
                        </form>
                </div>
            </div>
        </div>
    </div>

    <?php
    include '../footer/footer.php';
    ?>
</body>
</html>

<?php
include '../header/header.php';
require_once('../require/connection.php');

?>
<body>
<?php
include 'navbar.php';
?>
<div class="container-fluid">
<div class="row">
<div class="col-lg-3 col-md-12 col-sm-12">
<?php 
include 'sidebar.php';
?>
</div>
<?php
$query = "SELECT * FROM user_feedback WHERE user_id IS NOT NULL ORDER BY feedback_id DESC";
$result = mysqli_query($connection,$query);
?>
<div class="col-lg-9 col-md-12 col-sm-12" style="margin-top: 60px;">
  <div class="col-12 my-5">
  <h3 class="text-center fw-bold p-3 rounded shadow" style="background-color: #FFD700;border:3px solid #001F3F;">Registered Users Feedback</h3>
<div class="table table-responsive">
<table  id="table_id" class="display" style="width:100%" data-ordering="false">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Feedback</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($row = mysqli_fetch_assoc($result)) {
            ?>
            <tr>
                <td><?php echo $row['user_name'];?></td>
                <td><?php echo $row['user_email'];?></td>
                <td><?php echo $row['feedback'];?></td>
            </tr>
            <?php
            }
            ?>
        </tbody>    
</table>
</div>
</div>
</div>
</div>
</div>
</body>
<?php
include '../footer/footer.php';
?>

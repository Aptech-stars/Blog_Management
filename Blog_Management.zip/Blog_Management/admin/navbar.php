<?php include 'session.php'; ?>
<nav class="navbar navbar-expand-lg fw-bold fixed-top p-2 rounded shadow-lg" style="background-color:#001F3F; border:2px solid  #FFD700;">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style="background-color:white;">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="font-family:sans-serif; font-weight: bold; font-size: 30px;">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="admin.php"style="color:white;"><img src="../images/blog.png" alt="" class="img-fluid rounded shadow-lg border border-light" style="height: 50px; width: 60px;"></a>
        </li>
        <center>
      </ul>
     
      <a class="navbar-brand" href="my_profile.php"style="color:white; font-family: cursive;"><img src="../<?php echo $admin['user_image']?>" alt="" class="img-fluid rounded-circle" style="width: 45px; height: 45px"> <?php echo $admin['first_name']." ".$admin['last_name']; ?></a>

      <a href="../logout.php"><button type="button" class="btn btn-outline-light" data-bs-toggle="modal">Logout</button></a>
       &nbsp;
    </div>
  </div>
</nav>
<?php
  if (isset($_REQUEST['message']) && isset($_REQUEST['alert'])) {
?>
<div class="container-fluid">
  <div class="text-center alert <?php echo $_REQUEST['alert']; ?> alert-dismissible fade show" role="alert" style="margin-top:100px;margin-bottom:-80px;">
    <strong> <?php echo $_REQUEST['message']; ?></strong>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
</div>
<?php
  }
?>
<?php
require_once('../require/connection.php');
if (isset($_POST['submit'])) {
    extract($_POST);
    $query = "UPDATE category SET category_title='".$title."',category_description='".$description."'WHERE category_id=$category_id";
    $result =mysqli_query($connection,$query);
    if ($result) {
        header("location:view_category.php?message=Category Updated Successfully&alert=alert-success");
    }
    else{
        header("location:view_category.php?message=Update Failed&alert=alert-danger");
    }

}
?>
<?php
require_once('../require/connection.php');
include 'session.php';


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';
require '../PHPMailer/src/Exception.php';



if (isset($_POST['submit'])) {
    extract($_POST);
    $tmp_name   = $_FILES['image']['tmp_name'];
    $file_name  = $_FILES['image']['name'];
    $path       = rand()."_".$file_name;
    $path_database  = "Images/".$path; 
    $folder = "../Images";
    $comment_allowed=0;
    if (isset($comments)) {
        $comment_allowed=1;
    }

    if(!is_dir($folder)){
        if(!mkdir($folder)){
        header("location:add_post.php?message=Folder Not Created&alert=alert-danger");     
        }
    }

    if(move_uploaded_file($tmp_name, $folder."/".$path)){
    $query = "INSERT INTO post VALUES(null,'".$blog_id."','".$category_id."','".$admin['user_id']."','".$title."','".$summary."','".$description."','".$path_database."','Active','".$comment_allowed."',null,null)";
    $result = mysqli_query($connection,$query);
    $query_get_post_id="SELECT post_id FROM post ORDER BY post_id DESC";
    $result_get_post_id=mysqli_query($connection,$query_get_post_id);
    $post_id_get=mysqli_fetch_assoc($result_get_post_id);
        if($result){
            if($_FILES['files']['error'][0]!='4'){
                $folder_attach = "../Attachments";
                if(!is_dir($folder_attach)){
                    if(!mkdir($folder_attach)){
                    header("location:admin.php?message=Folder Not Created");    
                    }
                }
                foreach ($_FILES['files']['name'] as $key => $value) {
                        $tmp_name = $_FILES['files']['tmp_name'][$key];
                        $file_name_original = $_FILES['files']['name'][$key];
                        $file_name_upload = rand()."_".$_FILES['files']['name'][$key];
                        $path = $folder_attach."/".$file_name_upload;
                        
                    if(move_uploaded_file($tmp_name, $path)){
                        $query = "INSERT INTO post_atachment VALUES(null,'".$post_id_get['post_id']."','".$file_name_original."','".$path."','Active',null,null)";
                        $result = mysqli_query($connection,$query);
                    }
                }
            }


            $query_send_email="SELECT * FROM following_blog FB INNER JOIN user U ON FB.follower_id=U.user_id INNER JOIN blog B ON FB.blog_following_id=B.blog_id WHERE B.blog_id='".$blog_id."' ";
            $result_send_email=mysqli_query($connection,$query_send_email);
            if ($result_send_email->num_rows>0) {
                while ($user_emails=mysqli_fetch_assoc($result_send_email)) {
                    $mail = new PHPMailer();
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->Port = 587;
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->SMTPAuth = true;
                    $mail->Username = 'hostafzal00@gmail.com';
                    $mail->Password = 'ndja lvck byxx jszq';
                    $mail->setFrom('hostafzal00@gmail.com', 'Online Blogging Application');
                    $mail->addReplyTo('hostafzal00@gmail.com', 'Online Blogging Application');
                    $mail->addAddress($user_emails['email']);
                    $mail->Subject = "New Post";
                    $mail->isHTML(true);
                    $mail->Body  = "A New Post Is Uploaded On Blog You Followed Login And See The Posts//";
                    $mail->send();
                }
            }
        header("location:add_post.php?message=Post Upload Success&alert=alert-success");
        }
        else
        {
            $error=mysqli_error($connection)." Some Errors ";
            header("location:add_post.php?message=$error&alert=alert-danger");
        }
    } 
}

?>

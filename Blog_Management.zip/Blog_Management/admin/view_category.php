<?php
include '../header/header.php';
require_once('../require/connection.php');
?>
<body>
<?php
include 'navbar.php';
?>
<div class="container-fluid">
<div class="row">
<div class="col-lg-3 col-md-12 col-sm-12">
<?php 
include 'sidebar.php';
$query = "SELECT * FROM category  WHERE user_id='".$admin['user_id']."' ORDER BY category_id DESC";
$result = mysqli_query($connection,$query);
?>
</div>
<div class="col-lg-9 col-md-12 col-sm-12" style="margin-top: 60px;">
  <div class="col-12 my-5">
  <h3 class="text-center fw-bold p-3 rounded shadow" style="background-color: #FFD700;border:3px solid #001F3F;">My Categories</h3>
<div class="table table-responsive">
<table  id="table_id" class="display" style="width:100%" data-ordering="false">
        <thead>
            <tr>
                <th>Category Title</th>
                <th>Category Description</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($row = mysqli_fetch_assoc($result)) {
            ?>
            <tr>
                <td><?php echo $row['category_title']; ?></td>
                <td><?php echo $row['category_description']; ?></td>
                <td><?php echo $row['category_status']; ?></td>
                <td>
                 <?php 
                 if ($row['category_status']=='Active') {
                    ?>
                    <a href="inactive_category.php?id=<?php echo $row['category_id']; ?>"><button class="btn btn-danger" style="width: 100px;">InActive</button></a>
                <?php  
                 }
                 ?>
                 <?php
                  if ($row['category_status']=='InActive') {
                     ?>
                     <a href="active_category.php?id=<?php echo $row['category_id']; ?>"><button class="btn btn-success" style="width: 100px;">Active</button></a>
                 <?php  
                  }
                  ?>
                  <a href="edit_category.php?id=<?php echo $row['category_id']; ?>"><button class="btn btn-warning" style="width: 100px;">Edit</button></a>
                </td>
            </tr>
            <?php
            }
            ?>
        </tbody>    
</table>
</div>
</div>
</div>
</div>
</div>
</body>
<?php
include '../footer/footer.php';
?>

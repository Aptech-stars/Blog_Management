<?php
require_once('require/connection.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

if (isset($_POST['send'])) {
	extract($_POST);
	$password=rand();
	$query="SELECT * FROM user WHERE email='".$email."'";
	$result=mysqli_query($connection,$query);
	if($result->num_rows>0){

		$query_update = "UPDATE user SET password='".$password."' WHERE email='".$email."' ";
	 	$result_update = mysqli_query($connection,$query_update);
		if($result_update){
			$mail = new PHPMailer();
			$mail->isSMTP();
			$mail->Host = 'smtp.gmail.com';
			$mail->Port = 587;
			$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
			$mail->SMTPAuth = true;
			$mail->Username = 'hostafzal00@gmail.com';
			$mail->Password = 'ndja lvck byxx jszq';
			$mail->setFrom('hostafzal00@gmail.com', 'Online Blogging Application');
			$mail->addReplyTo('hostafzal00@gmail.com', 'Online Blogging Application');
			$mail->addAddress("$email");
			$mail->Subject = "Reset Password";
			$mail->isHTML(true);
			$mail->Body  = "Your Password Reset Successfully Your Email : <b>$email</b> And Your Password : <b>$password</b> Kindly Login With This Password And Change Your New Password";
			if($mail->send()){
				header("location:index.php?message=Reset Password Success check Your Email&alert=alert-success");
			}
		}
		else{
			header("location:index.php?message=Reset Password Failed System Error&alert=alert-danger");
		}
				
	}

	else
	{
		header("location:index.php?message=Email Not Found&alert=alert-danger");
	}
	
	
}

?>

<?php
require_once("require/connection.php");
session_start();
if (isset($_POST['login'])) {
	extract($_POST);
$query = "SELECT * FROM user WHERE email = '".$email."' AND password = '".$password."'";
$result = mysqli_query($connection,$query);
	if ($result->num_rows>0) {
	$row = mysqli_fetch_assoc($result);
		if ($row['role_id'] ==1) {
			$_SESSION['user_id'] = $row['user_id'];
			$_SESSION['role_id'] = $row['role_id'];
			header("location:admin/admin.php?message=Login Success&alert=alert-success");
		}
		if ($row['role_id'] ==2) {
			if ($row['is_approved']=='Approved') {
				if ($row['is_active']=='Active') {
					$_SESSION['user_id'] = $row['user_id'];
					$_SESSION['role_id'] = $row['role_id'];
					$user_name=$row['first_name']." ".$row['last_name'];
					header("location:user/user.php?message=Welcome User $user_name&alert=alert-success");
				}
				if ($row['is_active']=='InActive') {
					header("location:index.php?message=Your Account Is InActive Contact Admin &alert=alert-warning");
				}
			}
			if ($row['is_approved']=='Pending') {
				header("location:index.php?message=Your Account Request Is Pending Wait For Admin Approval&alert=alert-warning");
			}
			if ($row['is_approved']=='Rejected') {
				header("location:index.php?message=Your Account Request Is Rejected From Admin..&alert=alert-danger");
			}
		}

	}
	else{
		header("location:index.php?message=Invalid Email Or Password&alert=alert-danger");
	}
}
?>
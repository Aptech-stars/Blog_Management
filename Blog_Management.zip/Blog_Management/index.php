<?php
session_start();
if (isset($_SESSION['role_id'])) {
  if ($_SESSION['role_id']==1) {
    header("location:admin/admin.php?message=Please Logout First&alert=alert-danger");
  }
  if ($_SESSION['role_id']==2) {
    header("location:user/user.php?message=Please Logout First&alert=alert-danger");
  }
}
include 'header/header.php';
include 'require/connection.php';
?>
<body>
<nav class="navbar navbar-expand-lg fw-bold fixed-top p-2 rounded shadow-lg" style="background-color:#001F3F; border:2px solid  #FFD700;">
  <div class="container-fluid">
    <a class="navbar-brand">
      <img src="logo" alt="Blog Logo" class="img-fluid rounded shadow-lg border border-warning" style="height: 50px; width: 60px;">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style="background-color:white;">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0"></ul>
      <button type="button" class="btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#login">Sign In</button>
      &nbsp;&nbsp;&nbsp;&nbsp;
      <a href="register.php">
        <button type="button" class="btn btn-outline-light">Sign Up</button>
      </a>
    </div>
  </div>
</nav>
<?php
  if (isset($_REQUEST['message']) && isset($_REQUEST['alert'])) {
?>
<div class="container-fluid">
  <div class="text-center alert <?php echo $_REQUEST['alert']; ?> alert-dismissible fade show" role="alert" style="margin-top:100px;margin-bottom:-80px;">
    <strong> <?php echo $_REQUEST['message']; ?></strong>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
</div>
<?php
  }
?>
<div class="container-fluid my-5 ">
<div class="row">
<div class="my-5 col-lg-3 col-xl-3 col-sm-12 col-md-12">
<div class="card">
  <div class="card-body">
    <h5 class="card-title p-3 fw-bold rounded shadow" style="background-color:  #FFD700;color: #030e12; text-align: center;border:2px solid #001F3F;">Slide Show</h5>
  </div>

  <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/img1.webp" class="d-block w-100 img-fluid p-4 rounded" alt="..." style="height: 235px;">
    </div>
    <div class="carousel-item">
      <img src="images/img2.jpg" class="d-block w-100 img-fluid p-4 rounded" alt="..." style="height: 235px;">
    </div>
    <div class="carousel-item">
      <img src="images/img3.jpg" class="d-block w-100 img-fluid p-4 rounded" alt="..." style="height: 235px;">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

</div>
 </div>

<div class="col-lg-3 col-xl-3 col-sm-12 col-md-12 my-5">
<div class="card">
  <div class="card-body">
    <h5 class="card-title p-3 fw-bold rounded shadow" style="background-color:  #FFD700;;color: #030e12; text-align: center;border:2px solid #001F3F;">About Us</h5>
     <h1 class="card-title text-center mt-3" style="font-family: cursive;text-shadow: 2px 3px khaki;">MY BLOGS</h1>
        <p class="card-text mt-3" style="font-weight: bold" >
          Blogging is like having a public journal where you can share your thoughts....
  </div>
        <center>
        <button type="button" class="btn btn-outline-light text-white rounded shadow mb-5 col-9 p-2" data-bs-toggle="modal" data-bs-target="#exampleModal" style="background-color: #001F3F;">Feedback Us
        </button>
        </center>

</div>
</div>



<div class="col-lg-6 col-xl-6 col-sm-12 col-md-12 my-5">
<div class="card">
 <div class="card-body" style="height: 330px;overflow: scroll;">
    <h5 class="card-title p-3 fw-bold rounded shadow" style="background-color:  #FFD700; text-align: center;border:2px solid #001F3F;">Categories</h5>

<?php
$category_query = "SELECT * FROM category WHERE category_status='Active' ORDER BY category_id DESC";
$category_result = mysqli_query($connection,$category_query);
if ($category_result->num_rows>0) {
   while ($category = mysqli_fetch_assoc($category_result)) {
?>

<div class="card mb-3">
  <div class="row g-0">
  	<h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color: #FFD700;border:2px solid #001F3F; ">Category Title : <?php echo $category['category_title'];?></h5>
  	<?php 
  	$query_post="SELECT * FROM post P INNER JOIN user U ON P.user_id=U.user_id WHERE P.category_id='".$category['category_id']."' AND P.post_status='Active' ORDER BY P.post_id DESC LIMIT 1";
	$post_result = mysqli_query($connection,$query_post);
	if ($post_result->num_rows>0) {
		while ($posts=mysqli_fetch_assoc($post_result)) {
  	?>
    <div class="col-md-4">
      <img src="<?php echo $posts['featured_image'];?>" style="height: 300px;" class="col-12 img-fluid rounded-start" alt="...">
 </div>
    <div class="col-md-8">
      <div class="card-body">
      	<h6 style="text-align: center;font-family: cursive;"><?php echo $posts['first_name'].' '.$posts['last_name'].' '.date('d-m-Y',strtotime($posts['created_at']));?></h6>
        <h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color: #FFD700;border:2px solid #001F3F; ">Post Title : <?php echo $posts['post_title'];?></h5>
          <h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color:#001F3F;border:2px solid  #FFD700;color: white; ">Post Summary : <?php echo $posts['post_summary'];?></h5>
        <h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color: #FFD700;border:2px solid #001F3F; ">Post Description</h5>
        <p class="border border-secondary p-2 rounded" style="font-weight:bold;"><?php echo $posts['post_description'];?></p>
      </div>
    </div>
    <?php
	}

	}
	else
	{
		echo "<h5 class='card-title text-center p-2 rounded shadow' style='font-family: cursive;font-style: bold;background-color:#001F3F;border:2px solid  #FFD700;color: white;'>No Posts Available In This Category</h5>";
	}
	
    ?>
  </div>
</div>
<?php
}
}
?>
</div>
</div>
</div>








</div>

<div class="row">	

<div class="col-6">
<div class="card">
 <div class="card-body" style="height: 600px;overflow: scroll;">
    <h5 class="card-title p-3 fw-bold rounded shadow" style="background-color: #001F3F;color: white; text-align: center;border:2px solid  #FFD700;">Recent Posts</h5>

<?php
$post_query = "SELECT * FROM post P INNER JOIN user U ON P.user_id=U.user_id WHERE P.post_status='Active' ORDER BY P.post_id DESC LIMIT 5";
$post_result = mysqli_query($connection,$post_query);
if ($post_result->num_rows>0) {
   while ($posts = mysqli_fetch_assoc($post_result)) {
?>

<div class="card mb-3">
  <div class="row g-0">
    <div class="col-md-4">
      <img src="<?php echo $posts['featured_image'];?>" style="height: 300px;" class="col-12 img-fluid rounded-start" alt="...">
 </div>
    <div class="col-md-8">
      <div class="card-body">
      	<h6 style="text-align: center;font-family: cursive;"><?php echo $posts['first_name'].' '.$posts['last_name'].' '.date('d-m-Y',strtotime($posts['created_at']));?></h6>
        <h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color: #FFD700;border:2px solid #001F3F; ">Post Title : <?php echo $posts['post_title'];?></h5>
          <h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color:#001F3F;border:2px solid  #FFD700;color: white; ">Post Summary : <?php echo $posts['post_summary'];?></h5>
        <h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color: #FFD700;border:2px solid #001F3F; ">Post Description</h5>
        <p class="border border-secondary p-2 rounded" style="font-weight:bold;"><?php echo $posts['post_description'];?></p>
      </div>
    </div>
  </div>
</div>
<?php
}
}
?>
</div>
</div>
</div>

<div class="col-6">
<div class="card">
  <div class="card-body" style="height: 600px;overflow: scroll;">
    <h5 class="card-title p-3 fw-bold rounded shadow" style="background-color: #001F3F;color: white; text-align: center;border:2px solid  #FFD700;">Blogs</h5>

<?php
$blog_query = "SELECT * FROM blog B INNER JOIN user U ON B.user_id=U.user_id WHERE B.blog_status='Active' ORDER BY B.blog_id DESC LIMIT 5";
$blog_result = mysqli_query($connection,$blog_query);
if ($blog_result->num_rows>0) {
   while ($blogs = mysqli_fetch_assoc($blog_result)) {
?>

<div class="card mb-3" style="background-image: url('<?php echo $blogs['blog_background_image'];?>');background-size: cover;">
  <div class="row g-0">
    <div class="col-md-12">
      <div class="card-body">
      	<h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color:#001F3F;border:2px solid  #FFD700;color:white; ">Blog Title : <?php echo $blogs['blog_title'];?></h5>
        <h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color: #FFD700;border:2px solid #001F3F; ">Created By : <?php echo $blogs['first_name'].' '.$blogs['last_name'];?></h5>
        <center>
        <img src="<?php echo $blogs['user_image'];?>" style="height: 100px; width: 100px;" class="col-12 img-fluid rounded rounded-circle" alt="...">
        </center>
      </div>
    </div>
  </div>
</div>
<?php
}
}
?>

</div>
</div>
</div>


</div>
</div>

 <h3 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color:#001F3F;border:2px solid  #FFD700;color: white; ">Copyright@<?php echo date('Y');?></h3>

</body>
<?php
include 'footer/footer.php';
include 'modals/modals.php';
?>   
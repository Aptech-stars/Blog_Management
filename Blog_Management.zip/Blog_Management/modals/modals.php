<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Write Message</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       <form action="feedback_process.php" method="POST">

       	<div class="mb-3">
		
			  <label for="exampleFormControlInput1" class="form-label">Name</label>
			  <input type="text" class="form-control" id="exampleFormControlInput1" name="name" required>
			</div>
			<div class="mb-3">
		
			<label for="exampleFormControlInput1" class="form-label">Email</label>
			  <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com" name="email" required>
			</div>

			<div class="mb-3">
			  <label for="exampleFormControlTextarea1" class="form-label">Message</label>
			  <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="message" required></textarea>
			</div>

			
      </div>
      <div class="modal-footer">
        
        <button type="button" class="btn" data-bs-dismiss="modal" style="background-color: #FFD700;">Cancel</button>
        <input type="submit" name="send_message" class="btn" value="Send" style="background-color:#001F3F;color: white;">
		</form>
      </div>
    </div>
  </div>
</div>





<div class="modal fade" id="login" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Login Here</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       <form method="POST" action="login_process.php">

       	
			<div class="mb-3">
		
			  <label for="exampleFormControlInput1" class="form-label">Email</label>
			  <input type="email" class="form-control" id="exampleFormControlInput1" name="email" required>
			</div>
			<div class="mb-3">
		
			  <label for="exampleFormControlInput1" class="form-label">Password</label>
			  <input type="Password" class="form-control" id="exampleFormControlInput1"name="password" required>
			</div>

			
      </div>
      <center>
      <div class="modal-footer">
      	
        <button type="button" class="btn " data-bs-dismiss="modal" style="background-color: #FFD700;">Cancel</button>
        <input type="submit" name="login" class="btn " value="Login" style="background-color:#001F3F;color: white;">
        <a href="" data-bs-toggle="modal" data-bs-target="#forget">Forget Password</a>
      </div>
          
		</form>
      </div>
    </div>
  </div>
</div>




<div class="modal fade" id="forget" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Write Your Email</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       <form method="POST" action="forget_process.php">

       	
			<div class="mb-3">
		
			  <label for="exampleFormControlInput1" class="form-label">Email</label>
			  <input type="email" class="form-control" id="exampleFormControlInput1" name="email" required>
			</div>

			
      </div>
      <div class="modal-footer">
        <button type="button" class="btn " data-bs-dismiss="modal" style="background-color: #FFD700;">Cancel</button>
        <input type="submit" name="send" class="btn " value="Send" style="background-color:#001F3F;color: white;">
          
		</form>
      </div>
    </div>
  </div>
</div>

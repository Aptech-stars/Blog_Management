<?php
require_once('require/connection.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

require_once("FPDF/fpdf.php");

if(isset($_POST['submit'])){
	extract($_POST);
	$tmp_name 	= $_FILES['file']['tmp_name'];
	$file_name 	= $_FILES['file']['name'];
	$path 		= rand()."_".$file_name;
	$path_database 	= "Images/".$path; 

	$folder = "Images";
	if(!is_dir($folder)){
		if(!mkdir($folder)){
		header("location:index.php?message=Folder Not Created&alert=alert-danger");		
		}
	}

	if(move_uploaded_file($tmp_name, $folder."/".$path)){
		$query ="INSERT INTO user VALUES(null,2,'".$first_name."','".$last_name."','".$email."','".$password."','".$gender."','".$date_of_birth."','".$path_database."','".$address."','Pending','InActive',null,null)";
		$result = mysqli_query($connection,$query);
		if ($result) {
			$pdf = new FPDF();
			$pdf->AddPage();
			$pdf->SetFont("Arial", "BIU", 50);
			$pdf->ln(13);
			$pdf->Cell(0, 10, "Blogs", 0, 1, "C");
			$pdf->Image($path_database, 170, 5,30,40);
			$pdf->ln(20);
			$pdf->SetFont("Times", "BIU", 25);
			$pdf->Cell(0, 10, "User Details", 0, 1, "C");
			$pdf->SetFont("Times", "BI", 15);
			$pdf->ln(7);
			$pdf->MultiCell(0,13,"First Name : ".$first_name,0,"C");
			$pdf->MultiCell(0,13,"Last Name : ".$last_name,0,"C");
			$pdf->MultiCell(0,13,"Data Of Birth : ".date('d-M-Y',strtotime($date_of_birth)),0,"C");
			$pdf->MultiCell(0,13,"Email : ".$email,0,"C");
			$pdf->MultiCell(0,13,"Password : ".$password,0,"C");
			$pdf->MultiCell(0,13,"Gender : ".$gender,0,"C");
			$pdf->MultiCell(0,13,"Address : ".$address,0,"C");
			$pdf->Output("F","attachments/$email.pdf");

			$mail = new PHPMailer();
			$mail->isSMTP();
			$mail->Host = 'smtp.gmail.com';
			$mail->Port = 587;
			$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
			$mail->SMTPAuth = true;
			$mail->Username = 'hostafzal00@gmail.com';
			$mail->Password = 'ndja lvck byxx jszq';
			$mail->setFrom('hostafzal00@gmail.com', 'Online Blogging Application');
			$mail->addReplyTo('hostafzal00@gmail.com', 'Online Blogging Application');
			$mail->addAddress("$email");
			$mail->Subject = "Account Registration";
			$mail->isHTML(true);
			$mail->Body  = "Account Registration Successfully Kindly Wait For Admin Approval Your Email : <b>$email</b> And Your Password : <b>$password</b> You Will Recieve Admin Approval Email Also Your Details Is Attached With This Email";
			$mail->addAttachment("attachments/$email.pdf");

			if ($mail->send()) {
				$query = "SELECT email FROM user WHERE role_id=1";
				$result = mysqli_query($connection,$query);

				while ($row = mysqli_fetch_assoc($result)) {
				$mail = new PHPMailer();
				$mail->isSMTP();
				$mail->Host = 'smtp.gmail.com';
				$mail->Port = 587;
				$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
				$mail->SMTPAuth = true;
				$mail->Username = 'hostafzal00@gmail.com';
				$mail->Password = 'ndja lvck byxx jszq';
				$mail->setFrom('hostafzal00@gmail.com', 'Online Blogging Application');
				$mail->addReplyTo('hostafzal00@gmail.com', 'Online Blogging Application');
				$mail->addAddress($row['email']);
				$mail->Subject = "Account Registration";
				$mail->isHTML(true);
				$mail->Body  = "User Is Registered In Your Application And Waiting For Your Approval";
				$mail->send();
				}
			}
			header("location:register.php?message=Registered Success&alert=alert-success");
		}
		else
		{
			$error=mysqli_error($connection)." Some Errors ";
			header("location:register.php?message=$error&alert=alert-danger");
		}
	}
	else
	{
	header("location:register.php?message=Error In Registration&alert=alert-danger");
	}

}
else{
	header("location:index.php?message=fill form first&alert=alert-danger");
}
?>
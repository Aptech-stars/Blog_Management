/*
SQLyog Ultimate v12.5.0 (32 bit)
MySQL - 10.1.37-MariaDB : Database - 20035_muhammad_afzal
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`20035_muhammad_afzal` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `20035_muhammad_afzal`;

/*Table structure for table `blog` */

DROP TABLE IF EXISTS `blog`;

CREATE TABLE `blog` (
  `blog_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `blog_title` varchar(200) DEFAULT NULL,
  `post_per_page` int(11) DEFAULT NULL,
  `blog_background_image` text,
  `blog_status` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`blog_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `blog_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;

/*Data for the table `blog` */

insert  into `blog`(`blog_id`,`user_id`,`blog_title`,`post_per_page`,`blog_background_image`,`blog_status`,`created_at`,`updated_at`) values 
(6,1,'my new blog',15,'Images/1123672504_ak22.jpg','InActive','2024-05-20 03:22:55','2024-05-21 00:52:09'),
(7,1,'News ',5,'Images/276684491_ak24.jpg','Active','2024-05-21 00:49:02','2024-05-21 00:49:02'),
(8,1,'Cricket',5,'Images/996943544_1894482143_download (1).jpg','Active','2024-05-22 10:52:55','2024-05-22 10:52:55'),
(10,1,'information technology',4,'Images/1830894088_admin.jpg','Active','2024-05-22 10:56:44','2024-05-22 10:56:44'),
(11,1,'Hidaya Trust Cat',4,'Images/141043428_1830894088_admin.jpg','Active','2024-05-23 11:01:50','2024-05-23 11:01:50');

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_title` varchar(100) DEFAULT NULL,
  `category_description` text,
  `category_status` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4;

/*Data for the table `category` */

insert  into `category`(`category_id`,`category_title`,`category_description`,`category_status`,`created_at`,`updated_at`,`user_id`) values 
(2,'cricket','world cup','InActive','2024-05-18 10:27:04','2024-05-23 10:41:37',1),
(6,'News','today nes','InActive','2024-05-16 10:49:15','2024-05-23 10:41:32',1),
(11,'movies','entertainment','Active','2024-05-18 12:55:23','2024-05-21 00:46:35',1),
(15,'IT','information technology','Active','2024-05-18 12:02:42','2024-05-23 02:09:28',1),
(16,'News ','This is News Category','Active','2024-05-21 00:44:18','2024-05-21 00:44:18',1),
(17,'Hidaya Trust Cat','Hidaya Trust ','Active','2024-05-23 11:01:24','2024-05-23 11:01:24',1);

/*Table structure for table `following_blog` */

DROP TABLE IF EXISTS `following_blog`;

CREATE TABLE `following_blog` (
  `follow_id` int(11) NOT NULL AUTO_INCREMENT,
  `follower_id` int(11) DEFAULT NULL,
  `blog_following_id` int(11) DEFAULT NULL,
  `status` enum('Followed','Unfollowed') DEFAULT 'Followed',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`follow_id`),
  KEY `blog_following_id` (`blog_following_id`),
  KEY `follower_id` (`follower_id`),
  CONSTRAINT `following_blog_ibfk_1` FOREIGN KEY (`blog_following_id`) REFERENCES `blog` (`blog_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `following_blog_ibfk_2` FOREIGN KEY (`follower_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

/*Data for the table `following_blog` */

insert  into `following_blog`(`follow_id`,`follower_id`,`blog_following_id`,`status`,`created_at`,`updated_at`) values 
(1,23,6,'Unfollowed','2024-05-27 03:57:33','2024-05-27 04:53:30'),
(2,48,7,'Followed','2024-05-27 04:05:26','2024-05-27 04:05:26');

/*Table structure for table `post` */

DROP TABLE IF EXISTS `post`;

CREATE TABLE `post` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `post_title` varchar(200) NOT NULL,
  `post_summary` text NOT NULL,
  `post_description` longtext NOT NULL,
  `featured_image` text,
  `post_status` enum('Active','InActive') DEFAULT NULL,
  `is_comment_allowed` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`post_id`),
  KEY `blog_id` (`blog_id`),
  CONSTRAINT `post_ibfk_1` FOREIGN KEY (`blog_id`) REFERENCES `blog` (`blog_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4;

/*Data for the table `post` */

insert  into `post`(`post_id`,`blog_id`,`category_id`,`user_id`,`post_title`,`post_summary`,`post_description`,`featured_image`,`post_status`,`is_comment_allowed`,`created_at`,`updated_at`) values 
(10,6,15,1,'My New Post Title','My New Post Summary','My New Post Description TEST','Images/333712790_afzal.jpg','InActive',1,'2024-05-21 01:22:44','2024-05-21 02:14:46'),
(11,6,16,1,'Nostrud soluta et et','Eligendi asperiores ','Quia perferendis ips','Images/1253824794_ak2.jpg','Active',1,'2024-05-21 01:29:40','2024-05-21 01:29:40'),
(12,7,16,1,'Tempora blanditiis q','Recusandae In labor','Quidem similique eiu','Images/1945525572_ak6.jpg','InActive',0,'2024-05-21 01:30:19','2024-05-21 02:11:47'),
(13,6,15,1,'Cillum pariatur Ali','Do provident cupidi','Corporis aperiam ali','Images/453547405_afzal.jpg','Active',1,'2024-05-21 02:51:33','2024-05-21 02:51:33'),
(14,6,16,1,'Officia proident po','Aspernatur labore do','Voluptatem vel ea e','Images/1552344767_ak5.jpg','Active',1,'2024-05-21 02:52:37','2024-05-22 03:13:16'),
(15,10,16,1,'Hidaya Trust Cat','Hidaya Trust Abcd',' HIDAYA TRUST HIDAYA TRUST ','Images/2030929713_1965389263_download (1).jpg','Active',1,'2024-05-23 11:03:12','2024-05-25 18:10:41'),
(16,11,17,1,'Hidaya Trust','Hidaya Foundation','Foundation Hidaya','Images/467232207_afzal.jpg','Active',1,'2024-05-25 18:06:48','2024-05-27 02:35:21'),
(17,11,16,1,'Test Title','Test Summary','Test Description','Images/103618222_afzal.jpg','Active',1,'2024-05-27 02:00:01','2024-05-27 02:00:01'),
(18,6,16,1,'Proident proident ','Officia aliquid sit ','Nisi cillum odit dol','Images/918976160_afzal.jpg','Active',1,'2024-05-27 04:53:58','2024-05-27 04:53:58');

/*Table structure for table `post_atachment` */

DROP TABLE IF EXISTS `post_atachment`;

CREATE TABLE `post_atachment` (
  `post_atachment_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `post_attachment_title` varchar(200) DEFAULT NULL,
  `post_attachment_path` text,
  `is_active` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`post_atachment_id`),
  KEY `fk1` (`post_id`),
  CONSTRAINT `fk1` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4;

/*Data for the table `post_atachment` */

insert  into `post_atachment`(`post_atachment_id`,`post_id`,`post_attachment_title`,`post_attachment_path`,`is_active`,`created_at`,`updated_at`) values 
(1,17,'aa.html','../Attachments/274716484_aa.html','Active','2024-05-27 02:00:01','2024-05-27 02:00:01'),
(2,17,'aaaa.html','../Attachments/1332259795_aaaa.html','Active','2024-05-27 02:00:01','2024-05-27 02:00:01'),
(3,17,'afzal.jpg','../Attachments/1856445258_afzal.jpg','Active','2024-05-27 02:00:02','2024-05-27 02:00:02'),
(4,17,'ak2.jpg','../Attachments/1368930629_ak2.jpg','Active','2024-05-27 02:00:02','2024-05-27 02:00:02'),
(5,17,'ak3.jpg','../Attachments/1755304084_ak3.jpg','Active','2024-05-27 02:00:02','2024-05-27 02:00:02'),
(6,17,'ak4.jpg','../Attachments/351030225_ak4.jpg','InActive','2024-05-27 02:00:02','2024-05-27 02:18:41'),
(7,17,'ak5.jpg','../Attachments/383084477_ak5.jpg','InActive','2024-05-27 02:00:02','2024-05-27 02:08:51'),
(8,17,'ak6.jpg','../Attachments/843804824_ak6.jpg','Active','2024-05-27 02:00:02','2024-05-27 02:19:14'),
(9,15,'aa.html','../Attachments/1746458336_aa.html','Active','2024-05-27 02:34:26','2024-05-27 02:34:26'),
(10,15,'aaaa.html','../Attachments/1102006280_aaaa.html','Active','2024-05-27 02:34:26','2024-05-27 02:34:26'),
(11,15,'afzal.jpg','../Attachments/588750752_afzal.jpg','Active','2024-05-27 02:34:26','2024-05-27 02:34:26'),
(12,15,'ak2.jpg','../Attachments/1543998146_ak2.jpg','Active','2024-05-27 02:34:26','2024-05-27 02:34:26'),
(13,15,'ak3.jpg','../Attachments/1754454193_ak3.jpg','Active','2024-05-27 02:34:26','2024-05-27 02:34:26'),
(14,15,'ak4.jpg','../Attachments/1665764759_ak4.jpg','Active','2024-05-27 02:34:26','2024-05-27 02:34:26'),
(15,15,'ak5.jpg','../Attachments/1799855660_ak5.jpg','Active','2024-05-27 02:34:26','2024-05-27 02:34:26'),
(16,15,'ak6.jpg','../Attachments/1520452762_ak6.jpg','Active','2024-05-27 02:34:26','2024-05-27 02:34:26'),
(17,16,'aa.html','../Attachments/1673234300_aa.html','InActive','2024-05-27 02:35:02','2024-05-27 02:35:40'),
(18,16,'aaaa.html','../Attachments/2077282792_aaaa.html','Active','2024-05-27 02:35:02','2024-05-27 02:35:02'),
(19,16,'afzal.jpg','../Attachments/1835373424_afzal.jpg','Active','2024-05-27 02:35:03','2024-05-27 02:35:03'),
(20,16,'ak2.jpg','../Attachments/1426501073_ak2.jpg','Active','2024-05-27 02:35:03','2024-05-27 02:35:03'),
(21,16,'ak3.jpg','../Attachments/263303281_ak3.jpg','Active','2024-05-27 02:35:03','2024-05-27 02:35:03'),
(22,16,'ak4.jpg','../Attachments/1250344146_ak4.jpg','Active','2024-05-27 02:35:03','2024-05-27 02:35:03'),
(23,16,'ak5.jpg','../Attachments/90495941_ak5.jpg','Active','2024-05-27 02:35:03','2024-05-27 02:35:03'),
(24,16,'ak6.jpg','../Attachments/413989260_ak6.jpg','Active','2024-05-27 02:35:03','2024-05-27 02:35:03'),
(25,16,'ak7.jpg','../Attachments/1976449674_ak7.jpg','Active','2024-05-27 02:35:03','2024-05-27 02:35:03'),
(26,16,'ak8.jpg','../Attachments/1111236356_ak8.jpg','Active','2024-05-27 02:35:04','2024-05-27 02:35:04'),
(27,16,'ak9.jpg','../Attachments/2116351715_ak9.jpg','Active','2024-05-27 02:35:04','2024-05-27 02:35:04'),
(28,16,'ak10.jpg','../Attachments/1261602771_ak10.jpg','InActive','2024-05-27 02:35:04','2024-05-27 02:35:46'),
(29,16,'aa.html','../Attachments/1576672579_aa.html','Active','2024-05-27 02:35:22','2024-05-27 02:35:22'),
(30,16,'aaaa.html','../Attachments/270058014_aaaa.html','Active','2024-05-27 02:35:22','2024-05-27 02:35:22'),
(31,16,'afzal.jpg','../Attachments/175826343_afzal.jpg','Active','2024-05-27 02:35:22','2024-05-27 02:35:22'),
(32,16,'ak2.jpg','../Attachments/412719301_ak2.jpg','Active','2024-05-27 02:35:22','2024-05-27 02:35:22'),
(33,16,'ak3.jpg','../Attachments/1971188017_ak3.jpg','Active','2024-05-27 02:35:22','2024-05-27 02:35:22'),
(34,16,'ak4.jpg','../Attachments/1744571760_ak4.jpg','InActive','2024-05-27 02:35:22','2024-05-27 02:35:49'),
(35,16,'ak5.jpg','../Attachments/88862537_ak5.jpg','InActive','2024-05-27 02:35:22','2024-05-27 02:35:48'),
(36,16,'ak6.jpg','../Attachments/1746276149_ak6.jpg','InActive','2024-05-27 02:35:22','2024-05-27 02:35:47');

/*Table structure for table `post_category` */

DROP TABLE IF EXISTS `post_category`;

CREATE TABLE `post_category` (
  `post_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`post_category_id`),
  KEY `post_id` (`post_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `post_category_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `post_category_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `post_category` */

/*Table structure for table `post_comment` */

DROP TABLE IF EXISTS `post_comment`;

CREATE TABLE `post_comment` (
  `post_comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `comment` text,
  `is_active` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`post_comment_id`),
  KEY `user_id` (`user_id`),
  KEY `post_id` (`post_id`),
  CONSTRAINT `post_comment_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `post_comment_ibfk_2` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

/*Data for the table `post_comment` */

insert  into `post_comment`(`post_comment_id`,`post_id`,`user_id`,`comment`,`is_active`,`created_at`) values 
(3,14,47,'Hello','InActive','2024-05-22 03:22:05'),
(4,14,26,'Good Post','InActive','2024-05-22 11:14:46'),
(7,14,26,'comment work remaining','InActive','2024-05-22 13:15:12'),
(8,14,49,'Hello 123','Active','2024-05-23 02:49:51'),
(9,15,50,'Hidaya Trust Jamshoro','InActive','2024-05-23 11:06:39'),
(10,14,48,'Hello 1237','Active','2024-05-27 02:52:28'),
(11,16,48,'Hi','InActive','2024-05-27 03:18:05'),
(12,16,48,'Hi','InActive','2024-05-27 03:21:21'),
(13,16,48,'Hello 1237','InActive','2024-05-27 03:33:13'),
(14,16,48,'hjhjd','InActive','2024-05-27 03:34:27');

/*Table structure for table `role` */

DROP TABLE IF EXISTS `role`;

CREATE TABLE `role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_type` varchar(50) NOT NULL,
  `is_active` enum('Active','InActive') DEFAULT 'Active',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

/*Data for the table `role` */

insert  into `role`(`role_id`,`role_type`,`is_active`) values 
(1,'Admin','Active'),
(2,'User','Active');

/*Table structure for table `setting` */

DROP TABLE IF EXISTS `setting`;

CREATE TABLE `setting` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `setting_key` varchar(100) DEFAULT NULL,
  `setting_value` varchar(100) DEFAULT NULL,
  `setting_status` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `setting_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `setting` */

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` text NOT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `user_image` text,
  `address` text,
  `is_approved` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `is_active` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4;

/*Data for the table `user` */

insert  into `user`(`user_id`,`role_id`,`first_name`,`last_name`,`email`,`password`,`gender`,`date_of_birth`,`user_image`,`address`,`is_approved`,`is_active`,`created_at`,`updated_at`) values 
(1,1,'Muhammad Afzal','Kakepoto','muhammadafzalkakepoto202000@gmail.com','afzal123','Male','2000-08-20','Images/1776199502_afzal.jpg','Lakhidar, Shikarpur Sindh PK','Approved','Active','2024-05-14 11:04:16','2024-05-20 21:57:14'),
(23,2,'afzal','kakepoto','afzalkakepoto786@gmail.com','73868304','Male','2024-05-24','Images/807936101_car3.jpg','shp','Rejected','InActive','2024-05-15 12:39:58','2024-05-23 02:31:23'),
(26,2,'Muhammad','Afzal','muhammadafzal202000@gmail.com','12345','Male','2024-05-07','Images/738479536_download.jpg','ABCD\r\n','Approved','Active','2024-05-16 01:44:01','2024-05-22 01:29:53'),
(31,2,'Muhammad','Tahir','muhammadtahir@gmail.com','12345','Male','2024-05-29','Images/1809578825_download (1).jpg','hyd','Pending','InActive','2024-05-16 10:13:34','2024-05-21 20:54:29'),
(46,2,'Muhammad','Mutahir','muhammadmutahir@gmail.com','muthair','Male','2024-05-22','Images/1797166445_ak23.jpg','Shp','Approved','Active','2024-05-18 11:09:14','2024-05-20 21:58:44'),
(47,2,'Muhammad','Shoaib','muhammadshoaib@gmail.com','123456','Male','2024-05-03','Images/1775628385_ak5.jpg','Sukkur SINDH PK\r\n','Approved','Active','2024-05-18 11:53:00','2024-05-22 03:09:19'),
(48,2,'Hassan','Usman','hmemon6565@gmail.com','memon','Male','1999-05-20','Images/1037943832_ak22.jpg','HYD SINDH PK','Approved','Active','2024-05-20 03:09:05','2024-05-25 18:38:35'),
(49,2,'Muhammad','Tayab','muhammadtayab@gmail.com','taya123','Male','2002-02-25','Images/500999349_1965389263_download (1).jpg','Islamabad','Approved','Active','2024-05-22 09:51:06','2024-05-23 02:48:12'),
(50,2,'Hidaya','Trusts','hidayatrust@gmail.com','hidaya','Male','2013-12-05','Images/668800779_996943544_1894482143_download (1).jpg','Jamshoro','Approved','Active','2024-05-23 10:57:34','2024-05-25 18:14:42'),
(51,2,'Hassan','Memon','hassan123@gmail.com','hassan123','Male','2024-05-30','Images/375569878_ak5.jpg','Hyderabad','Pending','InActive','2024-05-27 00:59:19','2024-05-27 00:59:19');

/*Table structure for table `user_feedback` */

DROP TABLE IF EXISTS `user_feedback`;

CREATE TABLE `user_feedback` (
  `feedback_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `feedback` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`feedback_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

/*Data for the table `user_feedback` */

insert  into `user_feedback`(`feedback_id`,`user_id`,`user_name`,`user_email`,`feedback`,`created_at`) values 
(1,47,'Afzal','afzalkakepoto786@gmail.com','Feedback New Message','2024-05-16 03:28:59'),
(2,31,'talha','talha@gmail.com','good application\r\n','2024-05-16 11:09:05'),
(3,NULL,'tahir','tahir@gmail.com','helloo feedback working','2024-05-16 12:15:50'),
(4,NULL,'tahir','tahir@gmail.com','hauhajshjahsjahsjahsjahsa','2024-05-17 12:31:52'),
(5,26,'Muhammad Afzal','muhammadafzal202000@gmail.com','good app','2024-05-22 02:08:40');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

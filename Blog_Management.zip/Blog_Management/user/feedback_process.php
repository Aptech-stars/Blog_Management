<?php
require_once('../require/connection.php');
include 'session.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';
require '../PHPMailer/src/Exception.php';


if(isset($_POST['send_message'])){
	extract($_POST);

	$query ="INSERT INTO user_feedback VALUES(null,'".$user_id."','".$name."','".$email."','".$message."',null)";
	$result = mysqli_query($connection,$query);
	if ($result) {

		$mail = new PHPMailer();
		$mail->isSMTP();
		$mail->Host = 'smtp.gmail.com';
		$mail->Port = 587;
		$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
		$mail->SMTPAuth = true;
		$mail->Username = 'hostafzal00@gmail.com';
		$mail->Password = 'ndja lvck byxx jszq';
		$mail->setFrom('hostafzal00@gmail.com', 'Online Blogging Application');
		$mail->addReplyTo('hostafzal00@gmail.com', 'Online Blogging Application');
		$mail->addAddress("$email");
		$mail->Subject = "Thanks For Feedback";
		$mail->isHTML(true);
		$mail->Body  = "Thanks For Feedback Us If You Want To See New Posts We Are Inviting You To Register In Our Appplication";

		if ($mail->send()) {
			$query = "SELECT email FROM user WHERE role_id=1";
			$result = mysqli_query($connection,$query);

			while ($row = mysqli_fetch_assoc($result)) {
			$mail = new PHPMailer();
			$mail->isSMTP();
			$mail->Host = 'smtp.gmail.com';
			$mail->Port = 587;
			$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
			$mail->SMTPAuth = true;
			$mail->Username = 'hostafzal00@gmail.com';
			$mail->Password = 'ndja lvck byxx jszq';
			$mail->setFrom('hostafzal00@gmail.com', 'Online Blogging Application');
			$mail->addReplyTo('hostafzal00@gmail.com', 'Online Blogging Application');
			$mail->addAddress($row['email']);
			$mail->Subject = "New Feedback From User";
			$mail->isHTML(true);
			$mail->Body  = "A New Feedback From User Name: $name And Email: $email Please Login And See What User Feedback For Your Application..";
			$mail->send();
			}
		}
		header("location:user.php?message=Message Sent Successfully..&alert=alert-success");
	}
	else
	{
		$error=mysqli_error($connection)." Some Errors ";
		header("location:user.php?message=$error&alert=alert-danger");
	}
}
else{
	header("location:user.php?message=fill form first&alert=alert-danger");
}
?>
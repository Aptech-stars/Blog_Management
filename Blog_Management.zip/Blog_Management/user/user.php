<?php
include '../header/header.php';
include 'navbar.php';

?>
<body>
<div class="container-fluid">
<div class="row">
<div class="col-xl-3 col-lg-3 col-xxl-3 col-sm-12 col-md-12">
<?php include 'sidebar.php'; ?>
</div>



<div class="col-xl-9 col-lg-9 col-xxl-9 col-sm-12 col-md-12">
<div class="card border border-secondary" style="margin-top: 100px; height: 750px; overflow: scroll;">
  <div class="card-body">
       <h5 class="card-title p-3 fw-bold rounded shadow" style="background-color:  #FFD700; text-align: center;border:2px solid #001F3F;">All Posts</h5>
       <?php
       $post_query = "SELECT * FROM post WHERE post_status='Active' ORDER BY post_id DESC";
       $post_result = mysqli_query($connection,$post_query);
       if ($post_result->num_rows>0) {
       	 while ($posts = mysqli_fetch_assoc($post_result)) {
       ?>
       <div class="card mb-3">
         <div class="row g-0">
           <div class="col-md-4">
             <img src="../<?php echo $posts['featured_image'];?>" style="width: 400px;height: 350px;" class="img-fluid rounded-start" alt="...">
        </div>
           <div class="col-md-8">
             <div class="card-body">
               <h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color: #FFD700;border:2px solid #001F3F; "><?php echo $posts['post_title'];?></h5>
                 <h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color:#001F3F;border:2px solid  #FFD700;color: white; "><?php echo $posts['post_summary'];?></h5>
               <h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color: #FFD700;border:2px solid #001F3F; ">Post Description</h5>
               <p class="border border-secondary p-2 rounded" style="font-weight:bold;"><?php echo $posts['post_description'];?></p>
               <center>
               	<a href="view_full_post.php?id=<?php echo $posts['post_id'];?>&action=user.php">
               		<button type="button" class="btn btn-outline-light text-white rounded shadow mb-5 col-4 p-2" style="background-color: #001F3F;">View Full Post
               		</button>
               	</a>
               </center>
             </div>
           </div>
         </div>
       </div>
       <?php
      }
      }
      else{
      	echo "<h1 style='color:red; text-align:center;'>No Post Available</h1>";
      }
      ?>


  </div>
</div>
 </div>
</div>


<?php
include '../footer/footer.php';
?>
<?php
require_once('../require/connection.php');
include 'session.php';

if(isset($_POST['submit'])){
	extract($_POST);

	if ($action=='follow_add') {
	$query ="INSERT INTO following_blog VALUES(null,'".$follower_id."','".$blog_id."','Followed',null,null)";
	$result = mysqli_query($connection,$query);

		if ($result) 
		{
			header("location:blogs.php?message=Followed Successfully..&alert=alert-success&id=$blog_id");
		}
		else
		{
			$error=mysqli_error($connection)." Some Errors ";
			header("location:blogs.php?message=$error&alert=alert-danger&id=$blog_id");
		}
	}

	if ($action=='unfollow') {
	$query ="UPDATE following_blog SET status='Unfollowed' WHERE blog_following_id='".$blog_id."' AND follower_id='".$follower_id."'";
	$result = mysqli_query($connection,$query);
		if ($result) 
		{
			header("location:blogs.php?message=UnFollowed Successfully..&alert=alert-success&id=$blog_id");
		}
		else
		{
			$error=mysqli_error($connection)." Some Errors ";
			header("location:blogs.php?message=$error&alert=alert-danger&id=$blog_id");
		}
	}

	if ($action=='follow') {
	$query ="UPDATE following_blog SET status='Followed' WHERE blog_following_id='".$blog_id."' AND follower_id='".$follower_id."'";
	$result = mysqli_query($connection,$query);
		if ($result) 
		{
			header("location:blogs.php?message=Followed Successfully..&alert=alert-success&id=$blog_id");
		}
		else
		{
			$error=mysqli_error($connection)." Some Errors ";
			header("location:blogs.php?message=$error&alert=alert-danger&id=$blog_id");
		}
	}


}
else{
	header("location:view_full_post_by_blog.php?message=Error&alert=alert-danger&id=$blog_id");
}
?>
<?php
include '../header/header.php';
?>

<body>
    <?php
    include 'navbar.php';
    $query = "SELECT * FROM user WHERE user_id='".$user['user_id']."'";
    $result = mysqli_query($connection,$query);
    $row = mysqli_fetch_assoc($result);
    ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-md-12 col-sm-12">
                <?php include 'sidebar.php'; ?>
            </div>

            <div class="col-lg-9 col-md-12 col-sm-12" style="margin-top: 60px;">
                <div class="col-12 my-5">
                 
                    <h3 class="text-center fw-bold p-3 rounded shadow" style="background-color: #FFD700;border:3px solid #001F3F;"><a href="user.php" style="float: left;"><button class="btn btn-info">Back</button></a> My Profile</h3>
                       <form class="row g-3" action="edit_user_process.php" method="POST" enctype="multipart/form-data">
                    <center>
                    <div class="table-responsive">
                    <table class="table align-middle mb-0 bg-white">
                    <thead class="bg-light">
                      <tr>
                          <th></th>
                          <th>Gender</th>
                          <th>Password</th>
                          <th>Date of Birth</th>
                          <th>Address</th>
                          <th>Last Updated</th>
                          <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <div class="d-flex align-items-center">
                            <img
                                src="../<?php echo $user['user_image'];?>"
                                alt=""
                                style="width: 45px; height: 45px"
                                class="rounded-circle"
                                />
                            <div class="ms-3">
                              <p class="fw-bold mb-1"><?php echo $user['first_name']." ".$user['last_name']?></p>
                              <p class="text-muted mb-0"><?php echo $user['email']?></p>
                            </div>
                          </div>
                        </td>
                        <td>
                          <p class="fw-normal mb-1"><?php echo $user['gender']?></p>
                        </td>
                        <td><?php echo $user['password']?></td>
                        <td><?php echo date('d-M-Y',strtotime($user['date_of_birth']))?></td>
                        <td><?php echo $user['address']?></td>
                        <td><?php echo $user['updated_at']?></td>
                        <td>
                          <a href="edit_user.php"><button type="button" class="btn" style="background-color:#001F3F;color: white;">Edit</button></a>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  </div>
                  </center>
                </div>
            </div>
        </div>
    </div>
    <?php
    include '../footer/footer.php';
    ?>
</body>
</html>

<div class="card border border-secondary" style="margin-top: 100px;">

   <div class="card-body">
     <h5 class="card-title p-3 fw-bold rounded shadow" style="background-color:  #FFD700;color: #030e12; text-align: center;border:2px solid #001F3F;">Slide Show</h5>
   </div>

   <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
   <div class="carousel-inner">
     <div class="carousel-item active">
       <img src="../images/img1.webp" class="d-block w-100 img-fluid p-4 rounded" alt="..." style="height: 235px;">
     </div>
     <div class="carousel-item">
       <img src="../images/img2.jpg" class="d-block w-100 img-fluid p-4 rounded" alt="..." style="height: 235px;">
     </div>
     <div class="carousel-item">
       <img src="../images/img3.jpg" class="d-block w-100 img-fluid p-4 rounded" alt="..." style="height: 235px;">
     </div>
   </div>
   <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
     <span class="carousel-control-prev-icon" aria-hidden="true"></span>
     <span class="visually-hidden">Previous</span>
   </button>
   <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
     <span class="carousel-control-next-icon" aria-hidden="true"></span>
     <span class="visually-hidden">Next</span>
   </button>
 </div>

</div>

<div class="card my-3 border border-secondary">
  <div class="card-body">
    <h5 class="card-title p-3 fw-bold rounded shadow" style="background-color:  #FFD700;;color: #030e12; text-align: center;border:2px solid #001F3F;">About Us</h5>
     <h1 class="card-title text-center mt-3" style="font-family: cursive;text-shadow: 2px 3px khaki;">MY BLOGS</h1>
     <form method="POST" action="feedback_process.php">
        <div class="col-md-12">
              <textarea class="form-control border border-secondary" id="message" rows="5" name="message" required placeholder="Write Your Feedback Here............"></textarea>
        </div>
  </div>
        <center>
          <input type="hidden" name="user_id" value="<?php echo $user['user_id'];?>">
          <input type="hidden" name="email" value="<?php echo $user['email'];?>">
          <input type="hidden" name="name" value="<?php echo $user['first_name'].' '.$user['last_name'];?>">
        <input type="submit" name="send_message" value="Feedback Us" class="btn btn-outline-light text-white rounded shadow mb-5 col-9 p-2" style="background-color: #001F3F;">
    </form>

        </center>

</div>

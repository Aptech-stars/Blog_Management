<?php
include '../header/header.php';
include 'navbar.php';

?>
<body>
<div class="container-fluid">
<div class="row">
<div class="col-xl-3 col-lg-3 col-xxl-3 col-sm-12 col-md-12">
<?php include 'sidebar.php'; ?>
</div>



<div class="col-xl-9 col-lg-9 col-xxl-9 col-sm-12 col-md-12">
<div class="card border border-secondary" style="margin-top: 100px;">
  <div class="card-body" style="height: 600px;overflow: scroll;">
    <h5 class="card-title p-4 fw-bold rounded shadow" style="background-color: #001F3F;color: white; text-align: center;border:2px solid  #FFD700;"><a href="user.php"><button style="float: left;" class="btn btn-outline-dark">View All Posts</button></a>Blogs</h5>

<?php
$blog_id='';
if (isset($_REQUEST['id'])) {
  $blog_id=$_REQUEST['id'];
}
$blog_query = "SELECT * FROM blog B INNER JOIN user U ON B.user_id=U.user_id INNER JOIN post P ON B.blog_id=P.blog_id WHERE B.blog_status='Active' AND B.blog_id = $blog_id ORDER BY B.blog_id DESC";
$blog_result = mysqli_query($connection,$blog_query);
if ($blog_result->num_rows>0) {
   while ($blogs = mysqli_fetch_assoc($blog_result)) {
?>

<div class="card mb-3" style=" background-image: url('../<?php echo $blogs['blog_background_image'];?>');background-size: cover;">
  <div class="row g-0">
    <div class="col-md-12">
      <div class="card-body">
        <h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color:#001F3F;border:2px solid  #FFD700; ">Blog Title : <?php echo $blogs['blog_title'];?></h5>
        <h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color: #FFD700;border:2px solid #001F3F; ">Created By : <?php echo $blogs['first_name'].' '.$blogs['last_name'];?></h5>
        <center>
        <img src="../<?php echo $blogs['user_image'];?>" style="height: 100px; width: 100px;" class="col-12 img-fluid rounded rounded-circle" alt="...">
        <?php
        $query_follow="SELECT * FROM following_blog WHERE follower_id = '".$user['user_id']."' AND blog_following_id='".$blogs['blog_id']."' ";
        $result_follow=mysqli_query($connection,$query_follow);
        if ($result_follow->num_rows>0) {
          $follow_details=mysqli_fetch_assoc($result_follow);
          if ($follow_details['status']=='Followed') {
            ?>
           <form action="follow_process.php" method="POST">
            <input type="hidden" name="follower_id" value="<?php echo $user['user_id'];?>">
            <input type="hidden" name="blog_id" value="<?php echo $blogs['blog_id'];?>">
            <input type="hidden" name="action" value="unfollow">
            <input type="submit" name="submit" value="Unfollow" class="btn btn-info">
          </form>
          <?php
          }
          else{
            ?>
             <form action="follow_process.php" method="POST">
            <input type="hidden" name="follower_id" value="<?php echo $user['user_id'];?>">
            <input type="hidden" name="blog_id" value="<?php echo $blogs['blog_id'];?>">
            <input type="hidden" name="action" value="follow">
            <input type="submit" name="submit" value="Follow" class="btn btn-info">
            </form>
            <?php
          }
        ?>
       
        <?php
          }
          else{
            ?>
             <form action="follow_process.php" method="POST">
            <input type="hidden" name="follower_id" value="<?php echo $user['user_id'];?>">
            <input type="hidden" name="blog_id" value="<?php echo $blogs['blog_id'];?>">
            <input type="hidden" name="action" value="follow_add">
            <input type="submit" name="submit" value="Follow" class="btn btn-info">
            </form>
            <?php
          }
        ?>
        </center>


        <div class="card mb-3 my-2">
          <div class="row g-0">
            <div class="col-md-4">
              <img src="../<?php echo $blogs['featured_image'];?>" style="height: 300px;" class="col-12 img-fluid rounded-start" alt="...">
         </div>
            <div class="col-md-8">
              <div class="card-body">
                <h6 style="text-align: center;font-family: cursive;"><?php echo $blogs['first_name'].' '.$blogs['last_name'].' '.date('d-m-Y',strtotime($blogs['created_at']));?></h6>
                <h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color: #FFD700;border:2px solid #001F3F; ">Post Title : <?php echo $blogs['post_title'];?></h5>
                  <h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color:#001F3F;border:2px solid  #FFD700;color: white; ">Post Summary : <?php echo $blogs['post_summary'];?></h5>
                <h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color: #FFD700;border:2px solid #001F3F; ">Post Description</h5>
                <p class="border border-secondary p-2 rounded" style="font-weight:bold;"><?php echo $blogs['post_description'];?></p>
                <center>
                  <a href="view_full_post_by_blog.php?id=<?php echo $blogs['post_id'];?>&action=blogs.php&blog_id=<?php echo $blog_id;?>">
                    <button type="button" class="btn btn-outline-light text-white rounded shadow mb-5 col-4 p-2" style="background-color: #001F3F;">View Full Post
                    </button>
                  </a>
                </center>
              </div>
            </div>
          </div>
        </div>



      </div>
    </div>
  </div>
</div>
<?php
}
}
?>

</div>
</div>
 </div>
</div>


<?php
include '../footer/footer.php';
?>
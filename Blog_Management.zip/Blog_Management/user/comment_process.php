<?php
require_once('../require/connection.php');
include 'session.php';

if(isset($_POST['comment_post'])){
	extract($_POST);

	$query ="INSERT INTO post_comment VALUES(null,'".$post_id."','".$user_id."','".$comment."','InActive',null)";
	$result = mysqli_query($connection,$query);
	if ($result) 
	{
		header("location:view_full_post.php?message=Comment Successfully..&alert=alert-success&id=$post_id");
	}
	else
	{
		$error=mysqli_error($connection)." Some Errors ";
		header("location:view_full_post.php?message=$error&alert=alert-danger&id=$post_id");
	}
}
else{
	header("location:view_full_post.php?message=Error&alert=alert-danger&id=$post_id");
}
?>
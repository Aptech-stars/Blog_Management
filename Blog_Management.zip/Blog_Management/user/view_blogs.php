<?php
include '../header/header.php';
include 'navbar.php';

?>
<body>
<div class="container-fluid">
<div class="row">
<div class="col-xl-3 col-lg-3 col-xxl-3 col-sm-12 col-md-12">
<?php include 'sidebar.php'; ?>
</div>



<div class="col-xl-9 col-lg-9 col-xxl-9 col-sm-12 col-md-12">
<div class="card border border-secondary" style="margin-top: 100px;">
  <div class="card-body">
       <h5 class="card-title p-3 fw-bold rounded shadow" style="background-color:  #FFD700; text-align: center;border:2px solid #001F3F;"><a href="user.php" style="float: right;"><button class="btn btn-info p-1">Back</button></a>Blog Details</h5>
       


  </div>
</div>
 </div>
</div>


<?php
include '../footer/footer.php';
?>
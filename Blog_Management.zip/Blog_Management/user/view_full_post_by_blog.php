<?php
include '../header/header.php';
include 'navbar.php';

?>
<body>
<div class="container-fluid">
<div class="row">
<div class="col-xl-3 col-lg-3 col-xxl-3 col-sm-12 col-md-12">
<?php 

include 'sidebar.php';
 $blog_id="";
       if (isset($_REQUEST['blog_id'])) {
         $blog_id=$_REQUEST['blog_id'];
       }

 ?>
</div>



<div class="col-xl-9 col-lg-9 col-xxl-9 col-sm-12 col-md-12">
<div class="card border border-secondary" style="margin-top: 100px;">
  <div class="card-body">
       <h5 class="card-title p-3 fw-bold rounded shadow" style="background-color:  #FFD700; text-align: center;border:2px solid #001F3F;"><a href="blogs.php?id=<?php echo $blog_id;?>" style="float: right;"><button class="btn btn-info p-1">Back</button></a>Post Details</h5>
       <?php
       $post_id="";
       if (isset($_REQUEST['id'])) {
         $post_id=$_REQUEST['id'];
       }
      
       $post_query = "SELECT * FROM post P INNER JOIN user U  ON P.user_id=U.user_id WHERE P.post_status='Active' AND P.post_id=$post_id";
       $post_result = mysqli_query($connection,$post_query);
       if ($post_result->num_rows>0) {
       	 while ($posts = mysqli_fetch_assoc($post_result)) {
       ?>
       <div class="card mb-3">
         <div class="row g-0">
           <div class="col-md-12">
             <img src="../<?php echo $posts['featured_image'];?>" style="height: 300px;" class="col-12 img-fluid rounded-start" alt="...">
        </div>
        <div class="alert alert-info mt-3 text-center" role="alert">
          <?php echo $posts['first_name'].' '.$posts['last_name'].' '.date('d-M-Y',strtotime($posts['created_at']));?>
        </div>
           <div class="col-md-12">
             <div class="card-body">
              <?php
              $blog_query="SELECT * FROM blog WHERE blog_id='".$posts['blog_id']."'";
              $blog_result=mysqli_query($connection,$blog_query);
              $blog_details=mysqli_fetch_assoc($blog_result);
              ?>
              <h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color: #FFD700;border:2px solid #001F3F; ">Blog Name : <?php echo $blog_details['blog_title'];?></h5>
              <?php
              $category_query="SELECT * FROM category WHERE category_id='".$posts['category_id']."'";
              $category_result=mysqli_query($connection,$category_query);
              $category_details=mysqli_fetch_assoc($category_result);
              ?>
              <h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color:#001F3F;border:2px solid  #FFD700;color: white; ">Category Name : <?php echo $category_details['category_title'];?></h5>

               <h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color: #FFD700;border:2px solid #001F3F; ">Post Title : <?php echo $posts['post_title'];?></h5>
                 <h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color:#001F3F;border:2px solid  #FFD700;color: white; ">Post Summary : <?php echo $posts['post_summary'];?></h5>
                <h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color: #FFD700;border:2px solid #001F3F; ">Post Description</h5>
               <p class="card-text border border-secondary rounded shadow" style="font-weight: bold;height: 200px;overflow: scroll;text-align: center;"><?php echo $posts['post_description'];?></p>
               <center>
                <?php
                if ($posts['is_comment_allowed']==1) {
                ?>
                  <form method="POST" action="comment_process_by_blog.php">
                    <div class="input-group mb-3">
                      <input type="text" class="form-control" placeholder="Write Comment.." aria-describedby="button-addon2" name="comment" required>
                      <input type="hidden" name="user_id" value="<?php echo $user['user_id'];?>">
                      <input type="hidden" name="post_id" value="<?php echo $posts['post_id'];?>">
                      <input type="hidden" name="blog_id" value="<?php echo $blog_id;?>">
                      <input type="submit" class="btn btn-outline-warning" type="button" id="button-addon2" value="Comment" name="comment_post">
                    </div>
                  </form>
                <?php
                }
                else{
                  echo "<h4 style='color:red;text-align:center;'>Comments Are Not Allowed on this Post</h4>";
                }
                ?>
                <h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color: #FFD700;border:2px solid #001F3F; ">Comments</h5>

                <?php
                $comment_query ="SELECT * FROM post_comment PC INNER JOIN user U ON PC.user_id = U.user_id WHERE PC.post_id=$post_id AND PC.is_active='Active'";
                $comment_result=mysqli_query($connection,$comment_query);
                if ($comment_result->num_rows>0) {
                while ($row =mysqli_fetch_assoc($comment_result)) {
                ?>
                <div class="alert alert-primary" role="alert">
                <?php echo $row['first_name'].' '.$row['last_name'];?>
                -----
                <?php echo $row['comment'];?>
                -----
                <?php echo date('d-M-Y',strtotime($row['created_at']));?>
                </div>
                <?php
                }}
                else{
                  ?>

                <div class="alert alert-danger" role="alert">
                No Comments Available
                </div>

                <?php
                }
                ?>



                <h5 class="card-title text-center p-2 rounded shadow" style="font-family: cursive;font-style: bold;background-color: #FFD700;border:2px solid #001F3F; ">Attachments</h5>

                <?php
                $attachment_query ="SELECT * FROM post_atachment WHERE post_id=$post_id";
                $attachment_result=mysqli_query($connection,$attachment_query);
                if ($attachment_result->num_rows>0) {
                while ($row =mysqli_fetch_assoc($attachment_result)) {
                ?>
                <div class="alert alert-warning" role="alert">
                <?php echo $row['post_attachment_title'];?>
                -----
                <a href="<?php echo $row['post_attachment_path'];?>" download><?php echo $row['post_attachment_title'];?></a>
                </div>
                <?php
                }}
                else{
                  ?>

                <div class="alert alert-danger" role="alert">
                No Attachments Available
                </div>
                <?php
                }
                ?>
               </center>
             </div>
           </div>
         </div>
       </div>
       <?php
      }
      }
      else{
      	echo "<h1 style='color:red; text-align:center;'>No Post Available</h1>";
      }
      ?>


  </div>
</div>
 </div>
</div>


<?php
include '../footer/footer.php';
?>
<?php
mysqli_report(false);
$connection = mysqli_connect('localhost','root','','Blog_Management');

if (mysqli_connect_errno()) {
echo "<h1 style='color:red;'>".mysqli_connect_error()."....</h1>";
}

?>
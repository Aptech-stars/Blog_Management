<?php
include 'header/header.php';
?>
<body>
<nav class="navbar navbar-expand-lg fw-bold fixed-top p-2 rounded rounded-lg shadow-lg" style="background-color:#001F3F;border:2px solid  #FFD700;">
  <a class="navbar-brand" href="index.php"><img src="images/blog.png" alt="" class="img-fluid rounded shadow-lg border border-warning" style="height: 50px; width: 60px;"></a>
        <!-- <h1 style="color:white;font-family: cursive;">Online Blogging Application</h1> -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style="background-color:white;">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
     
      </ul>
        &nbsp;&nbsp;
        <button type="button" class="btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#login">Sign In</button>
       &nbsp;&nbsp;&nbsp;&nbsp;
       <a href="index.php"><button type="button" class="btn btn-outline-light" data-bs-toggle="modal">Go Back</button></a>
       &nbsp;
       
    </div>
  </div>
</nav>
<div class="container-fluid my-5">
<div class="row">
<div class="col-12 my-5">
<div class="card">
  <div class="card-body">
    <?php
    if (isset($_REQUEST['message']) && isset($_REQUEST['alert'])) {
    ?>
    <div class="text-center alert <?php echo $_REQUEST['alert']; ?> alert-dismissible fade show" role="alert">
      <strong> <?php echo $_REQUEST['message']; ?></strong>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php
    }
    ?>
   <h3 class="card-title p-3 fw-bold rounded shadow" style="background-color: #FFD700;  color: white; text-align: center;border:2px solid #001F3F;">Register Here</h3>

   <form class="row g-3" onsubmit="return validate()" action="register_process.php" method="POST" enctype="multipart/form-data">
  
    <h5><b>Note:</b> Required Field Are Marked With<span><b> *</b></span></h5>

  <div class="col-md-6">
    <label for="validationDefault01" class="form-label">First name : <span><b> *</b></span></label>
    <input type="text" class="form-control" id="first_name" value="" name="first_name" >
    <span id="first_name_msg"></span>
  </div>
  <div class="col-md-6">
    <label for="validationDefault02" class="form-label">Last name : <span><b> *</b></span></label>
    <input type="text" class="form-control" id="last_name" name="last_name">
    <span id="last_name_msg"></span>
  </div>
  <div class="col-md-6">
    <label for="validationDefaultUsername" class="form-label">Email : <span><b> *</b></span></label>
    <div class="input-group">
      <span class="input-group-text" id="inputGroupPrepend2">@</span>
      <input type="email" class="form-control" id="email" aria-describedby="inputGroupPrepend2"  name="email">
    </div>
      <span id="email_msg"></span>
  </div>
    <div class="col-md-6">
    <label for="validationDefaultUsername" class="form-label">Password : <span><b> *</b></span></label>
      <input type="password" class="form-control" id="password" aria-describedby="inputGroupPrepend2" name="password" >
      <span id="password_msg"></span>
    </div>
    <div class="col-md-3">
      <label for="exampleFormControlInput1" class="form-label">Gender : <span><b> *</b></span></label>
        <br>
        <label for="exampleFormControlInput1" class="form-label">Male</label>
        <input class="form-check-input" type="radio" name="gender" id="male" value="male">
      &nbsp;&nbsp;
      <!-- <div class="form-check"> -->
        <label class="form-check-label" for="flexRadioDefault1">Female</label>
        <input class="form-check-input" type="radio" name="gender" id="female" value="female">
      <br><span id="gender_msg"></span>

      </div>
  <div class="col-md-3">
    <label for="validationDefault03" class="form-label">Date Of Birth : <span><b> *</b></span></label>
    <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" >
    <span id="date_of_birth_msg"></span>
  </div>
   <div class="col-md-6">
    <label for="validationDefault03" class="form-label">Profile Image : <span>*</span></label>
    <input type="file" name="file" id="image" class="form-control" accept="image/*" id="validationDefault03" >
    <span id="image_msg"></span>

  </div>
  <div class="col-md-12">
  <label for="exampleFormControlTextarea1" class="form-label">Address : <span><b> *</b></span></label>
        <textarea class="form-control" id="address" rows="5" name="address"></textarea>
  </div>
    <span id="address_msg"></span>

</center>
  

  <div class="mb-3 mt-5 ml-5">
    <center>
      <a href="index.php"><button type="button" class="btn" data-bs-dismiss="modal" style="background-color: #FFD700;">Cancel</button></a>
      <input type="submit" name="submit" class="btn" value="Register" style="background-color:#001F3F;color: white;">
    </center>
    </div>
    </form>
  </div>
</div>
 </div>
</div>
</div>
</body>
<?php
include 'footer/footer.php';
include 'modals/modals.php';
?>
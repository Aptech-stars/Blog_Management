function validate(){
	var flag = true;
	var first_name   = document.getElementById('first_name').value
	var last_name    = document.getElementById('last_name').value
	var email        = document.getElementById('email').value
	var password     = document.getElementById('password').value
	var date_of_birth = document.getElementById('date_of_birth').value
	var image      = document.getElementById('image').value
  var address      = document.getElementById('address').value



   	var email_pattern        = /^[a-z]{3,}[0-9]*@[a-z]{2,}[.][a-z]{2,3}/;
    var password_pattern     = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;


   	if (first_name == "") {
   		flag = false;
   		document.getElementById('first_name_msg').innerHTML="First Name Is Required";
   	}
    else{
      document.getElementById('first_name_msg').innerHTML="";
    }
  


   	if (last_name=="") {
      flag = false;
   		document.getElementById('last_name_msg').innerHTML="Last Name Is Required";
   	}
    else{
      document.getElementById('last_name_msg').innerHTML="";
    }
  

   	if (email == "") {
   		flag = false;
   		document.getElementById('email_msg').innerHTML="Email is Required";
   	}
   	else{
   		document.getElementById('email_msg').innerHTML="";
   		if (email_pattern.test(email)==false) {
   		flag = false;
   		document.getElementById('email_msg').innerHTML="Email eg: afzal@gmail.com";
   		}
   	}

  if (password == "") {
      flag = false;
      document.getElementById('password_msg').innerHTML="Password is Required";
    }
    else{
      document.getElementById('password_msg').innerHTML="";
      if (password_pattern.test(password)==false) {
      flag = false;
      document.getElementById('password_msg').innerHTML="The Password Should be at least 8 Characters,Containing at Least a Character And a Number";
      }
    }



    if (document.getElementById('male').checked || document.getElementById('female').checked)
    {
    document.getElementById('gender_msg').innerHTML = "";
    } 
    else
    {
    flag = false;
    document.getElementById('gender_msg').innerHTML = "Please Select Gender";
   }

   	if (date_of_birth == "") {
   		flag = false;
   		document.getElementById('date_of_birth_msg').innerHTML="Date Of Birth Required";
   	}
   	
   	if (image == "") {
   		flag = false;
   		document.getElementById('image_msg').innerHTML="Image Is Required";
   	}



    if (address == "") {
      flag = false;
      document.getElementById('address_msg').innerHTML="Address Is Required";
    }
   
return flag;
}
